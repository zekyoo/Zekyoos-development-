package com.voltrace.client.core.rendering;
import com.voltrace.common.world.LodOctree.Key;
import java.util.*;
/** Frustum culling di CPU dari matriks MVP (Gribb-Hartmann). Posisi section dihitung relatif kamera, sama seperti saat digambar. */
public final class FrustumCull {
  private final float[] pl = new float[24];
  public FrustumCull(float[] m) {   // m = kolom-utama (kolom*4 + baris), hasil Matrix4f.get(float[])
    for (int i = 0; i < 6; i++) {
      int axis = i >> 1; float sgn = (i & 1) == 0 ? 1f : -1f;
      float a = m[3] + sgn * m[axis], b = m[7] + sgn * m[4 + axis], c = m[11] + sgn * m[8 + axis], d = m[15] + sgn * m[12 + axis];
      float l = (float) Math.sqrt(a * a + b * b + c * c); if (l < 1e-9f) l = 1f;
      pl[i * 4] = a / l; pl[i * 4 + 1] = b / l; pl[i * 4 + 2] = c / l; pl[i * 4 + 3] = d / l;
    }
  }
  /** Bola (pusat relatif kamera, radius) berada di luar salah satu bidang? */
  public boolean outside(double x, double y, double z, double r) {
    for (int i = 0; i < 6; i++) if (pl[i * 4] * x + pl[i * 4 + 1] * y + pl[i * 4 + 2] * z + pl[i * 4 + 3] < -r) return true;
    return false;
  }
  public static List<Key> cull(List<Key> keys, FrustumCull fr, double cx, double cy, double cz) {
    ArrayList<Key> out = new ArrayList<>(keys.size());
    for (Key k : keys) {
      double size = 32.0 * (1L << k.level()), h = size * 0.5;
      if (!fr.outside(k.sx() * size + h - cx, k.sy() * size + h - cy, k.sz() * size + h - cz, size * 0.87)) out.add(k);
    }
    return out;
  }
}
