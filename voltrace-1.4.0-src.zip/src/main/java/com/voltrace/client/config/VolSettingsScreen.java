package com.voltrace.client.config;
import com.voltrace.client.core.LodManager;
import net.minecraft.client.gui.screen.Screen; import net.minecraft.client.gui.tooltip.Tooltip; import net.minecraft.client.gui.widget.ButtonWidget; import net.minecraft.client.gui.widget.ClickableWidget; import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;
import java.util.ArrayList; import java.util.List; import java.util.function.*;
/**
 * Layar pengaturan VolTrace (dipakai bila tidak ada Sodium; dengan Sodium halaman yang sama ada di dalam Video Settings).
 * Tata letak: sidebar kategori di kiri, daftar opsi di kanan, tombol ON/OFF mod di pojok kanan-atas. Perubahan langsung berlaku dan disimpan saat ditutup.
 */
public final class VolSettingsScreen extends Screen {
  private static int page = 0;
  private static final String[] TABS = {"Umum", "Tampilan", "Bayangan", "Performa", "Lanjutan"};
  private final Screen parent; private ButtonWidget stats; private int tickN;
  public VolSettingsScreen(Screen parent) { super(Text.literal("VolTrace")); this.parent = parent; }

  private static final class Sl extends SliderWidget {
    private final String label; private final DoubleFunction<String> fmt; private final DoubleConsumer apply;
    Sl(int w, String label, double v, DoubleFunction<String> fmt, DoubleConsumer apply, String tip) { super(0, 0, w, 20, Text.empty(), Math.max(0, Math.min(1, v))); this.label = label; this.fmt = fmt; this.apply = apply; setTooltip(Tooltip.of(Text.literal(tip))); updateMessage(); }
    @Override protected void updateMessage() { setMessage(Text.literal(label + ": " + fmt.apply(value))); }
    @Override protected void applyValue() { apply.accept(value); }
  }
  private ButtonWidget cycle(int w, String label, String[] vals, Supplier<String> get, Consumer<String> set, String tip) {
    ButtonWidget[] self = new ButtonWidget[1];
    self[0] = ButtonWidget.builder(Text.literal(label + ": " + get.get()), b -> {
      int i = 0; for (int k = 0; k < vals.length; k++) if (vals[k].equals(get.get())) i = k;
      set.accept(vals[(i + 1) % vals.length]); self[0].setMessage(Text.literal(label + ": " + get.get())); }).dimensions(0, 0, w, 20).tooltip(Tooltip.of(Text.literal(tip))).build();
    return self[0];
  }
  private ButtonWidget toggle(int w, String label, BooleanSupplier get, Consumer<Boolean> set, String tip) {
    ButtonWidget[] self = new ButtonWidget[1];
    self[0] = ButtonWidget.builder(Text.literal(label + ": " + (get.getAsBoolean() ? "ON" : "OFF")), b -> { set.accept(!get.getAsBoolean()); self[0].setMessage(Text.literal(label + ": " + (get.getAsBoolean() ? "ON" : "OFF"))); })
      .dimensions(0, 0, w, 20).tooltip(Tooltip.of(Text.literal(tip))).build();
    return self[0];
  }
  private static double logT(int v, int min, int max) { return (Math.log(Math.max(min, v)) - Math.log(min)) / (Math.log(max) - Math.log(min)); }
  private static int logV(double t, int min, int max) { return (int) Math.round(Math.exp(Math.log(min) + t * (Math.log(max) - Math.log(min)))); }
  private static double linT(int v, int min, int max) { return (double) (v - min) / (max - min); }
  private static int linV(double t, int min, int max) { return (int) Math.round(min + t * (max - min)); }

  @Override protected void init() {
    int side = Math.min(92, width / 4), pad = 10, px = pad + side + 8, pw = width - px - pad, top = 34;
    // --- header: judul + tombol ON/OFF mod (besar, di kanan-atas) ---
    ButtonWidget head = ButtonWidget.builder(Text.literal("VolTrace"), b -> {}).dimensions(pad, 8, side, 20).build(); head.active = false; addDrawableChild(head);
    ButtonWidget master = toggle(Math.min(pw, 220), "VolTrace", () -> VolConfig.enabled, v -> VolConfig.enabled = v, "Menyalakan / mematikan seluruh mod secara manual di dalam game.");
    master.setX(width - pad - Math.min(pw, 220)); master.setY(8); addDrawableChild(master);
    // --- sidebar kategori ---
    for (int i = 0; i < TABS.length; i++) { final int p = i;
      ButtonWidget tb = ButtonWidget.builder(Text.literal((i == page ? "> " : "  ") + TABS[i]), b -> { page = p; clearAndInit(); }).dimensions(pad, top + i * 24, side, 20).build(); tb.active = i != page; addDrawableChild(tb); }
    // --- panel opsi ---
    int cw = Math.max(120, pw - 0); List<ClickableWidget> rows = new ArrayList<>(); int cores = Math.max(2, Math.min(8, Runtime.getRuntime().availableProcessors()));
    switch (page) {
      case 0 -> {
        rows.add(toggle(cw, "Ingest chunk dimuat", () -> VolConfig.ingest, v -> VolConfig.ingest = v, "Chunk yang dimuat game otomatis disimpan sebagai data LOD (cara kerja sama seperti Voxy)."));
        rows.add(toggle(cw, "Sintesis terrain jauh", () -> VolConfig.synth, v -> VolConfig.synth = v, "Membuat tampilan terrain jauh dari generator dunia tanpa membuat chunk (singleplayer). Hasilnya disimpan di disk."));
        rows.add(toggle(cw, "Generator chunk asli (eksperimental)", () -> VolConfig.generate, v -> VolConfig.generate = v, "Meminta server dunia membuat chunk asli di sekitar pemain. Lebih berat dan menulis chunk ke dunia."));
        rows.add(new Sl(cw, "Radius generator", VolConfig.genChunks <= 0 ? 0 : logT(VolConfig.genChunks, 1, 256), t -> t <= 0.001 ? "mati" : logV(t, 1, 256) + " chunk", t -> VolConfig.genChunks = t <= 0.001 ? 0 : logV(t, 1, 256), "Sejauh mana chunk asli dibuat."));
      }
      case 1 -> {
        rows.add(new Sl(cw, "Jarak render LOD", logT(VolConfig.renderChunks, 2, 1024), t -> logV(t, 2, 1024) + " chunk", t -> VolConfig.setChunks(logV(t, 2, 1024)), "Jarak LOD dalam chunk. Default 64."));
        rows.add(toggle(cw, "Tekstur blok", () -> VolConfig.textures, v -> VolConfig.textures = v, "Memakai tekstur blok asli (resource pack ikut). OFF = warna rata-rata."));
        rows.add(toggle(cw, "Cahaya matahari", () -> VolConfig.lighting, v -> VolConfig.lighting = v, "Pencahayaan terarah mengikuti posisi matahari."));
        rows.add(toggle(cw, "Kabut LOD", () -> VolConfig.fog, v -> VolConfig.fog = v, "Memudarkan LOD ke warna langit di tepi jarak render."));
      }
      case 2 -> {
        rows.add(toggle(cw, "Bayangan", () -> VolConfig.shadows, v -> VolConfig.shadows = v, "Bayangan matahari pada terrain LOD."));
        rows.add(new Sl(cw, "Radius bayangan", logT(Math.max(4, VolConfig.shadowChunks), 4, 512), t -> logV(t, 4, 512) + " chunk", t -> VolConfig.setShadowChunks(logV(t, 4, 512)), "Radius bayangan dari kamera dalam chunk. Default 64."));
        rows.add(cycle(cw, "Kualitas bayangan", new String[]{"1024", "2048", "4096"}, () -> "" + VolConfig.shadowRes, v -> VolConfig.shadowRes = Integer.parseInt(v), "Resolusi shadow map. 4096 lebih tajam tapi lebih berat."));
        rows.add(new Sl(cw, "Perbarui bayangan tiap", linT(VolConfig.shadowInterval, 1, 10), t -> linV(t, 1, 10) + " frame", t -> VolConfig.shadowInterval = linV(t, 1, 10), "Peta bayangan digambar ulang tiap N frame. Lebih besar = lebih ringan."));
      }
      case 3 -> {
        rows.add(new Sl(cw, "Skala render LOD", linT(VolConfig.renderScale, 50, 100), t -> (Math.round(linV(t, 50, 100) / 25f) * 25) + "%", t -> VolConfig.renderScale = Math.round(linV(t, 50, 100) / 25f) * 25, "Resolusi gambar LOD. 50-75% jauh lebih ringan untuk GPU lemah."));
        rows.add(new Sl(cw, "Upload mesh per frame", linT(VolConfig.uploadsPerFrame, 1, 32), t -> "" + linV(t, 1, 32), t -> VolConfig.uploadsPerFrame = linV(t, 1, 32), "Lebih kecil = frame lebih stabil saat LOD baru dimuat."));
        rows.add(new Sl(cw, "Thread worker", linT(Math.min(cores, VolConfig.buildThreads), 1, cores), t -> "" + linV(t, 1, cores), t -> { VolConfig.buildThreads = linV(t, 1, cores); LodManager.applyThreads(); }, "Thread untuk membangun mesh dan sintesis. Kurangi jika game tersendat."));
        rows.add(new Sl(cw, "Memori cache", logT(VolConfig.memoryMb, 128, 8192), t -> logV(t, 128, 8192) + " MB", t -> VolConfig.memoryMb = logV(t, 128, 8192), "Batas RAM data LOD; sisanya dibaca dari disk."));
      }
      default -> {
        rows.add(cycle(cw, "Backend", new String[]{"auto", "indirect", "classic", "cpu"}, () -> VolConfig.backend, v -> LodManager.setBackend(v), "auto: GPU modern (GL4.3) / klasik (GL3.2). cpu: cadangan tanpa dukungan GPU."));
        rows.add(cycle(cw, "Mode shader pack", new String[]{"auto", "post", "legacy", "off"}, () -> VolConfig.shaderMode, v -> VolConfig.shaderMode = v, "Cara menggambar bersama shader pack (Iris). auto sudah tepat; off = LOD mati saat shader pack aktif."));
        rows.add(cycle(cw, "Mode Android / GPU lemah", new String[]{"auto", "on", "off"}, () -> VolConfig.compat, v -> { VolConfig.compat = v; LodManager.setBackend(VolConfig.backend); LodManager.applyThreads(); }, "auto mendeteksi GPU mobile/iGPU. on = paksa mode hemat."));
        rows.add(toggle(cw, "Log diagnostik", () -> VolConfig.debug, v -> VolConfig.debug = v, "Menulis baris [diag] ke logs/latest.log untuk membantu mencari masalah."));
      }
    }
    int y = top; for (ClickableWidget w : rows) { w.setX(px); w.setY(y); addDrawableChild(w); y += 24; }
    // --- footer ---
    int fy = Math.max(y + 8, top + TABS.length * 24 + 4), half = (pw - 6) / 2;
    addDrawableChild(ButtonWidget.builder(Text.literal("Reset default"), b -> { VolConfig.resetDefaults(); LodManager.setBackend("auto"); LodManager.applyThreads(); clearAndInit(); }).dimensions(px, fy, half, 20).build());
    addDrawableChild(ButtonWidget.builder(Text.literal("Selesai"), b -> close()).dimensions(px + half + 6, fy, half, 20).build());
    stats = ButtonWidget.builder(Text.literal(LodManager.shortStatus()), b -> {}).dimensions(pad, fy + 26, width - pad * 2, 20).build(); stats.active = false; addDrawableChild(stats);
  }
  @Override public void tick() { super.tick(); if (stats != null && ++tickN % 10 == 0) stats.setMessage(Text.literal(LodManager.shortStatus())); }
  @Override public void close() { VolConfig.save(); if (client != null) client.setScreen(parent); }
}
