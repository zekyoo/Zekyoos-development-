package com.voltrace.client.config;
import net.fabricmc.loader.api.FabricLoader;
import java.io.*; import java.nio.file.*; import java.util.Properties;
/** Semua pengaturan VolTrace. Default: jarak LOD 64 chunk, bayangan 64 chunk. */
public final class VolConfig {
  public static final int MAX_CHUNKS = 8192, CONFIG_VERSION = 3;
  public static volatile boolean enabled = true, shadows = true, textures = true, lighting = true, fog = true, ingest = true, generate = false, synth = true, debug = false;
  public static volatile int renderChunks = 64, shadowChunks = 64, shadowRes = 2048, genChunks = 32, genMs = 8, uploadsPerFrame = 4, memoryMb = 512, renderScale = 100, shadowInterval = 3;
  public static volatile int buildThreads = Math.max(1, Math.min(3, Runtime.getRuntime().availableProcessors() / 2));
  public static volatile String backend = "auto", shaderMode = "auto", compat = "auto";   // backend: auto|indirect|classic|cpu ; shaderMode: auto|post|legacy ; compat (Android/GPU lemah): auto|on|off
  static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }
  public static int setChunks(int c) { return renderChunks = clamp(c, 2, MAX_CHUNKS); }
  public static int setShadowChunks(int c) { return shadowChunks = clamp(c, 0, MAX_CHUNKS); }
  public static void resetDefaults() {
    enabled = shadows = textures = lighting = fog = ingest = synth = true; generate = false; debug = false;
    renderChunks = 64; shadowChunks = 64; shadowRes = 2048; genChunks = 32; genMs = 8; uploadsPerFrame = 4; memoryMb = 512; renderScale = 100; shadowInterval = 3;
    buildThreads = Math.max(1, Math.min(3, Runtime.getRuntime().availableProcessors() / 2)); backend = "auto"; shaderMode = "auto"; compat = "auto";
  }
  private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("voltrace.properties"); }
  private static boolean b(Properties p, String k, boolean d) { String v = p.getProperty(k); return v == null ? d : Boolean.parseBoolean(v.trim()); }
  private static int i(Properties p, String k, int d) { try { String v = p.getProperty(k); return v == null ? d : Integer.parseInt(v.trim()); } catch (NumberFormatException e) { return d; } }
  public static void load() {
    Properties p = new Properties();
    try (InputStream in = Files.newInputStream(file())) { p.load(in); } catch (IOException e) { return; }
    if (i(p, "configVersion", 0) < CONFIG_VERSION) return;   // config lama (default berbeda) diabaikan -> pakai default baru 64/64
    enabled = b(p, "enabled", enabled); shadows = b(p, "shadows", shadows); textures = b(p, "textures", textures); lighting = b(p, "lighting", lighting);
    fog = b(p, "fog", fog); ingest = b(p, "ingest", ingest); generate = b(p, "generate", generate); synth = b(p, "synth", synth); debug = b(p, "debug", debug);
    setChunks(i(p, "renderChunks", renderChunks)); setShadowChunks(i(p, "shadowChunks", shadowChunks));
    int sr = i(p, "shadowRes", shadowRes); shadowRes = (sr == 1024 || sr == 4096) ? sr : 2048;
    genChunks = clamp(i(p, "genChunks", genChunks), 0, 512); genMs = clamp(i(p, "genMs", genMs), 1, 40); uploadsPerFrame = clamp(i(p, "uploadsPerFrame", uploadsPerFrame), 1, 64);
    memoryMb = clamp(i(p, "memoryMb", memoryMb), 128, 16384); renderScale = clamp(i(p, "renderScale", renderScale), 50, 100); shadowInterval = clamp(i(p, "shadowInterval", shadowInterval), 1, 10); buildThreads = clamp(i(p, "buildThreads", buildThreads), 1, 64);
    backend = p.getProperty("backend", backend); shaderMode = p.getProperty("shaderMode", shaderMode); compat = p.getProperty("compat", compat);
  }
  public static void save() {
    Properties p = new Properties(); p.setProperty("configVersion", "" + CONFIG_VERSION);
    p.setProperty("enabled", "" + enabled); p.setProperty("shadows", "" + shadows); p.setProperty("textures", "" + textures); p.setProperty("lighting", "" + lighting);
    p.setProperty("fog", "" + fog); p.setProperty("ingest", "" + ingest); p.setProperty("generate", "" + generate); p.setProperty("synth", "" + synth); p.setProperty("debug", "" + debug);
    p.setProperty("renderChunks", "" + renderChunks); p.setProperty("shadowChunks", "" + shadowChunks); p.setProperty("shadowRes", "" + shadowRes);
    p.setProperty("genChunks", "" + genChunks); p.setProperty("genMs", "" + genMs); p.setProperty("uploadsPerFrame", "" + uploadsPerFrame);
    p.setProperty("memoryMb", "" + memoryMb); p.setProperty("renderScale", "" + renderScale); p.setProperty("shadowInterval", "" + shadowInterval); p.setProperty("buildThreads", "" + buildThreads); p.setProperty("backend", backend); p.setProperty("shaderMode", shaderMode); p.setProperty("compat", compat);
    try (OutputStream o = Files.newOutputStream(file())) { p.store(o, "VolTrace"); } catch (IOException ignored) {}
  }
}
