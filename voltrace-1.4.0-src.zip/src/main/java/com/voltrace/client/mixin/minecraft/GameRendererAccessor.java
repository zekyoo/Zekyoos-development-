package com.voltrace.client.mixin.minecraft;
import net.minecraft.client.render.Camera; import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin; import org.spongepowered.asm.mixin.gen.Invoker;
/** FOV yang benar-benar dipakai vanilla untuk dunia (termasuk FOV dinamis saat lari/terbang/efek, air, dan mod zoom). Dipakai agar LOD tidak bergeser. */
@Mixin(GameRenderer.class)
public interface GameRendererAccessor {
  @Invoker("getFov") float voltrace$getFov(Camera camera, float tickProgress, boolean changingFov);
}
