package com.voltrace.client.mixin.minecraft;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.voltrace.client.core.LodManager;
import net.minecraft.client.render.Camera; import net.minecraft.client.render.RenderTickCounter; import net.minecraft.client.render.WorldRenderer; import net.minecraft.client.util.memory.ObjectAllocator;
import org.joml.Matrix4f; import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin; import org.spongepowered.asm.mixin.injection.At; import org.spongepowered.asm.mixin.injection.Inject; import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/** Menyalin matriks view + proyeksi yang BENAR-BENAR dipakai vanilla untuk dunia (termasuk bobbing, efek kamera, FOV dinamis, zoom). LOD memakai matriks yang sama persis, sehingga menempel mulus dengan chunk vanilla. */
@Mixin(WorldRenderer.class)
public abstract class MixinWorldRenderer {
  @Inject(method = "render", at = @At("HEAD"), require = 0)
  private void voltrace$captureMatrices(ObjectAllocator allocator, RenderTickCounter tickCounter, boolean renderBlockOutline, Camera camera, Matrix4f positionMatrix, Matrix4f basicProjectionMatrix, Matrix4f projectionMatrix, GpuBufferSlice fogBuffer, Vector4f fogColor, boolean renderSky, CallbackInfo ci) {
    LodManager.captureMatrices(positionMatrix, basicProjectionMatrix);
  }
}
