package com.voltrace.client.mixin.minecraft;
import com.voltrace.client.core.LodManager;
import net.minecraft.client.render.fog.FogRenderer;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin; import org.spongepowered.asm.mixin.injection.At; import org.spongepowered.asm.mixin.injection.Inject; import org.spongepowered.asm.mixin.injection.ModifyVariable; import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import java.nio.ByteBuffer;
/**
 * Memindahkan kabut vanilla ke LOD (seperti Voxy dan Distant Horizons): saat VolTrace aktif, kabut jarak-render vanilla digeser keluar sampai tepi LOD,
 * sehingga chunk vanilla tidak memudar di tepinya dan menyatu dengan LOD. Warna kabut vanilla juga dibaca di sini supaya LOD memakai warna yang persis sama.
 */
@Mixin(FogRenderer.class)
public abstract class MixinFogRenderer {
  private static final String APPLY = "applyFog(Ljava/nio/ByteBuffer;ILorg/joml/Vector4f;FFFFFF)V";
  @Inject(method = APPLY, at = @At("HEAD"), require = 0)
  private void voltrace$captureFog(ByteBuffer buffer, int bufPos, Vector4f fogColor, float environmentalStart, float environmentalEnd, float renderDistanceStart, float renderDistanceEnd, float skyEnd, float cloudEnd, CallbackInfo ci) {
    LodManager.captureFog(fogColor, environmentalStart, environmentalEnd, renderDistanceStart, renderDistanceEnd);
  }
  @ModifyVariable(method = APPLY, at = @At("HEAD"), argsOnly = true, ordinal = 2, require = 0)
  private float voltrace$fogStart(float v) { return LodManager.fogStartFor(v); }
  @ModifyVariable(method = APPLY, at = @At("HEAD"), argsOnly = true, ordinal = 3, require = 0)
  private float voltrace$fogEnd(float v) { return LodManager.fogEndFor(v); }
}
