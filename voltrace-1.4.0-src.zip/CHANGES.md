
## 1.3.0 (berdasarkan hasil tes 1.2.2)
- LOD bergeser saat bergerak/terbang: penyebabnya FOV. Sekarang FOV dinamis asli vanilla (lari, terbang, efek, air, mod zoom) dipakai untuk proyeksi LOD (`GameRendererAccessor`).
- LOD jadi hitam pekat: kecerahan LOD terlalu rendah saat sore/malam. Ada lantai kecerahan, warna kabut diambil dari langit yang tampil di layar, shader jatuh ke warna palet bila tekstur tidak valid, layar atlas kosong = abu-abu (bukan hitam).
- Halaman VolTrace di DALAM Video Settings Sodium (5 kategori: Umum, Tampilan, Bayangan, Performa, Lanjutan) termasuk ON/OFF mod; layar cadangan tanpa Sodium dibuat ulang (sidebar kategori + tombol ON/OFF mod).
- Performa: frustum culling (sebelumnya semua section digambar tiap frame), skala render LOD 50-100%, peta bayangan diperbarui tiap N frame (bergeser mengikuti kamera di antaranya), PCF 4 tap, thread worker default lebih sedikit dan berprioritas rendah, upload mesh/frame default 4.
- Generator chunk asli dimatikan secara default (bisa membebani server dan membuat chunk vanilla hilang); tampilan jauh memakai sintesis terrain yang tidak menyentuh dunia.
- `/voltrace prepare <chunk>`: menyiapkan LOD jauh di belakang layar dan menyimpannya ke disk (seperti Chunky), `0` untuk berhenti.
- `/voltrace status` menampilkan jumlah blok bertekstur/gagal, jumlah section digambar, FOV, dan skala render. Sprite yang tidak terbaca dicatat di log.

## 1.4.0
- Layar hitam saat shader pack dinyalakan: jalur pasca-Iris sekarang menunggu pipeline Iris selesai dibangun (2,5 detik), memvalidasi framebuffer tujuan, memeriksa GL error, dan punya penjaga layar-hitam (kalau layar menjadi hitam setelah komposit, LOD shader dimatikan otomatis + pesan di chat). Pilihan baru `Mode shader pack = off` (LOD mati saat shader pack aktif). Tombol darurat **Ctrl+Shift+V** menyalakan/mematikan mod walau layar hitam. Snapshot GL kini juga menyimpan viewport, polygon offset, dan sRGB.
- Author di metadata mod: ZEKYOO (juga ikon mod).
- Menu: halaman Sodium dijadikan SATU halaman "VolTrace Config" (grup di dalamnya); tombol VolTrace di pojok kiri-atas layar Options dihapus; toggle ON/OFF mod diberi nama "VolTrace".
- LOD tidak menyatu / miring mengikuti kamera: LOD sekarang memakai matriks view + proyeksi ASLI vanilla yang disalin tiap frame (bobbing, efek kamera, FOV dinamis, zoom ikut); hanya near/far yang diganti (`MixinWorldRenderer`).
- Kabut vanilla dipindahkan ke LOD seperti Voxy/DH (`MixinFogRenderer`): jarak kabut jarak-render vanilla digeser ke tepi LOD, warna kabut LOD = warna kabut vanilla persis, di air/lava/buta mengikuti kabut lingkungan vanilla. Hanya aktif saat LOD benar-benar tergambar.
