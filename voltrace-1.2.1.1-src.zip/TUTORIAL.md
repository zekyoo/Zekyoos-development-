# Tutorial lengkap: membuat (build) mod VolTrace jadi file .jar

Kamu tidak perlu menginstal apa pun di PC/HP. GitHub yang mem-build mod-nya gratis lewat file `.github/workflows/build.yml`.

## A. Siapkan repo GitHub (sekali saja)
1. Buka github.com, masuk (atau daftar gratis).
2. Tombol **+** (kanan atas) -> **New repository** -> nama bebas, mis. `voltrace` -> pilih Public atau Private -> **Create repository**.

## B. Upload project
1. Ekstrak zip project ini dulu di perangkatmu.
2. Di halaman repo: **Add file -> Upload files**, lalu seret SEMUA ISI folder hasil ekstrak (bukan file zip-nya): `src`, `gradle`, `build.gradle`, `gradle.properties`, `settings.gradle`, `gradlew`, `gradlew.bat`, `LICENSE`, `.gitignore`, `.gitattributes`, dan folder **`.github`**.
3. PENTING: folder `.github` bersifat tersembunyi dan sering tidak ikut terpilih (terutama di HP). Cek setelah upload: harus ada `.github/workflows/build.yml` di repo.
   Kalau tidak ada: **Add file -> Create new file**, ketik nama `.github/workflows/build.yml` (garis miring otomatis membuat folder), tempel isi file `build.yml` dari project ini, lalu **Commit changes**.
4. Pastikan `gradle/wrapper/gradle-wrapper.jar` ikut ter-upload. Kalau tidak ada, workflow otomatis mengunduh Gradle sendiri, jadi tidak masalah.
5. Klik **Commit changes**.

## C. Menjalankan build
1. Buka tab **Actions** di repo. Kalau ada tombol "I understand my workflows... enable", klik.
2. Setiap upload/commit memulai build otomatis. Untuk menjalankan manual: pilih workflow **Build VolTrace (.jar)** -> **Run workflow**.
3. Tunggu 5-15 menit (build pertama paling lama karena mengunduh Minecraft). Titik kuning = berjalan, centang hijau = berhasil, silang merah = gagal.

## D. Mengambil file mod
- Buka build yang hijau, scroll ke bagian **Artifacts**, unduh **VolTrace-mod-jar** (berupa zip kecil; di dalamnya ada `.jar`).
- Cara lain: tab **Releases** di halaman repo (build dari branch utama muncul sebagai "VolTrace (build terbaru)").
- JANGAN pakai file yang berakhiran `-sources.jar` atau `-dev.jar`.

## E. Kalau build gagal
1. Buka build yang merah -> klik **Summary** (ringkasan di halaman atas). Workflow menulis blok "Build gagal - salin teks di bawah ini".
2. Salin blok teks itu dan kirim ke Claude. Biasanya satu-dua baris `error:` cukup untuk diperbaiki.
3. Log lengkap ada di Artifacts bernama **build-logs**.

## F. Instalasi di Minecraft
1. Minecraft Java **1.21.11** dengan **Fabric Loader 0.20.1 atau lebih baru** (fabricmc.net/use).
2. **Fabric API** untuk 1.21.11 (wajib), versi 0.141.6 atau lebih baru.
3. Salin `.jar` VolTrace ke folder `mods` (`%appdata%\.minecraft\mods` di Windows).
4. Opsional, tapi didukung: **Sodium**, **Iris** (shader pack), **Mod Menu**.
5. Untuk Android (PojavLauncher/Zalith dll.): taruh jar di folder mods profil Fabric yang sama. Mod otomatis masuk mode kompatibilitas bila GPU terdeteksi mobile (Adreno, Mali, dll.).

## G. Cara memakai
- Menu pengaturan: **Options -> tombol VolTrace** (kiri-atas), di layar **Video Settings** (termasuk Sodium), atau lewat **Mod Menu**.
- Perintah: `/voltrace settings`, `/voltrace status`, `/voltrace distance <chunk>`, `/voltrace shadow <chunk>`, `/voltrace backend auto|indirect|classic|cpu`, `/voltrace shader auto|post|legacy`, `/voltrace compat auto|on|off`, `/voltrace toggle`, `/voltrace reload` (muat ulang tekstur setelah ganti resource pack), `/voltrace debug`, `/voltrace gpu`.
- Default: jarak LOD 64 chunk, bayangan 64 chunk.

## H. Tes yang disarankan (urut)
1. Dunia singleplayer baru, **render distance vanilla 2-4 chunk**, shader OFF. Terbang ke atas: tanah jauh harus tampil bertekstur, dan terrain/entity/pemain vanilla tidak tertimpa.
2. Ulangi dengan shader pack ON (Iris). LOD harus tetap terlihat (tanpa pencahayaan pack).
3. Jalankan `/voltrace status` dan lihat `backend`, `section terlihat`, `di GPU`.
4. Kalau ada yang salah: aktifkan `/voltrace debug`, mainkan 30 detik, lalu kirim `.minecraft/logs/latest.log` (cari baris yang berawalan "VolTrace" atau "[diag]") beserta screenshot.

## I. Menaikkan versi
Ubah `version=` di `gradle.properties`, commit, tunggu build baru. Untuk tag rilis: buat tag `v1.2.1` agar jar otomatis masuk Releases.
