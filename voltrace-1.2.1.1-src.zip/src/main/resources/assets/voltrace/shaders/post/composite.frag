#version 150
// Komposit LOD ke framebuffer akhir HANYA di piksel yang belum digambar apa pun (kedalaman scene == nilai clear).
// Terrain, entity, block entity, player, dan translucent vanilla tidak pernah tertimpa; kedalaman scene tidak diubah.
in vec2 uv;
uniform sampler2D uCol;   // warna LOD
uniform sampler2D uScn;   // salinan depth scene (mode 1)
uniform float uMode;      // 0 = tes depth hardware (GL_EQUAL), 1 = mask dari salinan depth
uniform float uClr;       // nilai clear depth
out vec4 o;
void main() {
  vec4 c = texture(uCol, uv);
  if (c.a < 0.5) discard;
  if (uMode > 0.5 && abs(texture(uScn, uv).r - uClr) > 0.00002) discard;
  gl_FragDepth = uClr;
  o = vec4(c.rgb, 1.0);
}
