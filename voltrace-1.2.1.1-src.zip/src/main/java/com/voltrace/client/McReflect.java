package com.voltrace.client;
import net.minecraft.client.render.Camera; import net.minecraft.client.render.model.BakedQuad; import net.minecraft.client.texture.Sprite;
import net.minecraft.util.Identifier; import net.minecraft.util.math.Vec3d;
import java.lang.reflect.Field; import java.lang.reflect.Method; import java.lang.reflect.RecordComponent;
/**
 * Beberapa anggota class Minecraft 1.21.11 tidak punya nama Yarn (posisi kamera, sprite milik quad, id sprite), sehingga
 * pemanggilan langsung tidak bisa dikompilasi. Anggota itu dicari lewat TIPE-nya (bukan namanya) sehingga jalan baik di dev maupun di game asli.
 */
public final class McReflect {
  private static Field camPos, spriteId; private static Method quadSprite; private static boolean quadTried;
  private McReflect() {}
  public static Vec3d cameraPos(Camera c) {
    try {
      if (camPos == null) for (Field f : Camera.class.getDeclaredFields()) if (f.getType() == Vec3d.class) { f.setAccessible(true); camPos = f; break; }
      return (Vec3d) camPos.get(c);
    } catch (Throwable t) { throw new IllegalStateException("posisi kamera tidak terbaca", t); }
  }
  public static Sprite sprite(BakedQuad q) {
    try {
      if (!quadTried) { quadTried = true;
        RecordComponent[] rc = BakedQuad.class.getRecordComponents();
        if (rc != null) for (RecordComponent r : rc) if (r.getType() == Sprite.class) { quadSprite = r.getAccessor(); quadSprite.setAccessible(true); break; } }
      return quadSprite == null ? null : (Sprite) quadSprite.invoke(q);
    } catch (Throwable t) { return null; }
  }
  /** Nama sprite seperti "minecraft:block/stone", atau "" kalau tidak terbaca. */
  public static String spriteName(Sprite s) {
    try {
      if (s == null) return "";
      Object contents = s.getContents();
      if (spriteId == null) for (Field f : contents.getClass().getDeclaredFields()) if (f.getType() == Identifier.class) { f.setAccessible(true); spriteId = f; break; }
      return ((Identifier) spriteId.get(contents)).toString();
    } catch (Throwable t) { return ""; }
  }
  public static String quadTexture(BakedQuad q) { return spriteName(sprite(q)); }
}
