package com.voltrace.client.compat;
import com.voltrace.client.VolTraceClient; import com.voltrace.client.config.VolConfig;
import org.lwjgl.opengl.*;
/** Deteksi GPU/driver (termasuk lapisan GL di Android: ANGLE, Zink, GL4ES, MobileGlues, dst). Mode "lowEnd" memakai jalur paling konservatif:
 *  backend Classic (hanya fitur GL 3.x / GLES 3.x), tanpa bayangan, upload mesh lebih sedikit, thread lebih sedikit. */
public final class GpuInfo {
  public static volatile boolean ready, mobile, gl43, gl33; public static String renderer = "?", vendor = "?", version = "?";
  private static final String[] MOBILE = {"adreno", "mali", "powervr", "immortalis", "xclipse", "angle", "zink", "gl4es", "mobileglues", "virgl", "freedreno", "turnip", "panfrost", "llvmpipe", "android"};
  public static void init() {
    if (ready) return; ready = true;
    try {
      renderer = String.valueOf(GL11.glGetString(GL11.GL_RENDERER)); vendor = String.valueOf(GL11.glGetString(GL11.GL_VENDOR)); version = String.valueOf(GL11.glGetString(GL11.GL_VERSION));
      GLCapabilities c = GL.getCapabilities(); gl43 = c.OpenGL43; gl33 = c.OpenGL33;
      String all = (renderer + " " + vendor + " " + version).toLowerCase(); for (String k : MOBILE) if (all.contains(k)) { mobile = true; break; }
      VolTraceClient.LOGGER.info("GPU: {} | {} | {} | mobile={} gl43={} gl33={}", renderer, vendor, version, mobile, gl43, gl33);
    } catch (Throwable t) { VolTraceClient.LOGGER.warn("deteksi GPU gagal: {}", t.toString()); }
  }
  public static boolean lowEnd() { String m = VolConfig.compat; return m.equals("on") || (m.equals("auto") && mobile); }
  public static String summary() { return renderer + " | " + vendor + " | GL " + version + " | mobile=" + mobile + " | mode kompatibilitas=" + (lowEnd() ? "AKTIF" : "mati"); }
}
