package com.voltrace.client.mixin.iris;
import com.voltrace.client.core.LodManager;
import org.spongepowered.asm.mixin.Mixin; import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At; import org.spongepowered.asm.mixin.injection.Inject; import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/** Dipanggil setelah Iris selesai menjalankan composite + final pass. LOD digambar ke framebuffer akhir (hanya di piksel kosong), jadi tidak dimakan
 *  G-buffer/pencahayaan shader pack. @Pseudo + require=0: kalau Iris tidak ada atau method berubah, mod tetap jalan. */
@Pseudo
@Mixin(targets = "net.irisshaders.iris.pipeline.IrisRenderingPipeline")
public abstract class MixinIrisRenderingPipeline {
  @Inject(method = "finalizeLevelRendering", at = @At("RETURN"), remap = false, require = 0)
  private void voltrace$afterIris(CallbackInfo ci) { LodManager.renderPost(); }
}
