package com.voltrace.client.config;
import com.voltrace.client.compat.GpuInfo; import com.voltrace.client.core.LodManager;
import net.minecraft.client.gui.screen.Screen; import net.minecraft.client.gui.widget.ButtonWidget; import net.minecraft.client.gui.widget.SliderWidget; import net.minecraft.text.Text;
import java.util.function.*;
/** Layar pengaturan VolTrace (dibuka dari Options, Video Settings Sodium, Mod Menu, atau /voltrace settings). Perubahan langsung berlaku dan disimpan saat ditutup. */
public final class VolSettingsScreen extends Screen {
  private final Screen parent;
  public VolSettingsScreen(Screen parent) { super(Text.literal("VolTrace")); this.parent = parent; }

  private static final class Sl extends SliderWidget {
    private final String label; private final DoubleFunction<String> fmt; private final DoubleConsumer apply;
    Sl(int x, int y, int w, int h, String label, double v, DoubleFunction<String> fmt, DoubleConsumer apply) { super(x, y, w, h, Text.empty(), Math.max(0, Math.min(1, v))); this.label = label; this.fmt = fmt; this.apply = apply; updateMessage(); }
    @Override protected void updateMessage() { setMessage(Text.literal(label + ": " + fmt.apply(value))); }
    @Override protected void applyValue() { apply.accept(value); }
  }
  private ButtonWidget cycle(int x, int y, int w, int h, String label, String[] vals, Supplier<String> get, Consumer<String> set) {
    ButtonWidget[] self = new ButtonWidget[1];
    self[0] = ButtonWidget.builder(Text.literal(label + ": " + get.get()), b -> {
      int i = 0; for (int k = 0; k < vals.length; k++) if (vals[k].equals(get.get())) i = k;
      set.accept(vals[(i + 1) % vals.length]); self[0].setMessage(Text.literal(label + ": " + get.get())); }).dimensions(x, y, w, h).build();
    return self[0];
  }
  private ButtonWidget toggle(int x, int y, int w, int h, String label, BooleanSupplier get, Consumer<Boolean> set) {
    ButtonWidget[] self = new ButtonWidget[1];
    self[0] = ButtonWidget.builder(Text.literal(label + ": " + (get.getAsBoolean() ? "ON" : "OFF")), b -> { set.accept(!get.getAsBoolean()); self[0].setMessage(Text.literal(label + ": " + (get.getAsBoolean() ? "ON" : "OFF"))); }).dimensions(x, y, w, h).build();
    return self[0];
  }
  private static double logT(int v, int min, int max) { return (Math.log(Math.max(min, v)) - Math.log(min)) / (Math.log(max) - Math.log(min)); }
  private static int logV(double t, int min, int max) { return (int) Math.round(Math.exp(Math.log(min) + t * (Math.log(max) - Math.log(min)))); }
  private static double linT(int v, int min, int max) { return (double) (v - min) / (max - min); }
  private static int linV(double t, int min, int max) { return (int) Math.round(min + t * (max - min)); }

  @Override protected void init() {
    int cw = Math.min(160, (width - 24) / 2), gap = 8, xl = width / 2 - cw - gap / 2, xr = width / 2 + gap / 2;
    int rows = 9, rh = Math.max(16, Math.min(24, (height - 70) / (rows + 1))), bh = rh - 2, y0 = 34, cores = Math.max(4, Runtime.getRuntime().availableProcessors());
    ButtonWidget head = ButtonWidget.builder(Text.literal("VolTrace - Pengaturan Render"), b -> {}).dimensions(width / 2 - 110, 8, 220, 20).build(); head.active = false; addDrawableChild(head);
    int y = y0;
    // --- kolom kiri: tampilan ---
    addDrawableChild(toggle(xl, y, cw, bh, "VolTrace", () -> VolConfig.enabled, v -> VolConfig.enabled = v)); y += rh;
    addDrawableChild(new Sl(xl, y, cw, bh, "Jarak LOD", logT(VolConfig.renderChunks, 2, VolConfig.MAX_CHUNKS), t -> logV(t, 2, VolConfig.MAX_CHUNKS) + " chunk", t -> VolConfig.setChunks(logV(t, 2, VolConfig.MAX_CHUNKS)))); y += rh;
    addDrawableChild(toggle(xl, y, cw, bh, "Bayangan", () -> VolConfig.shadows, v -> VolConfig.shadows = v)); y += rh;
    addDrawableChild(new Sl(xl, y, cw, bh, "Radius bayangan", VolConfig.shadowChunks <= 0 ? 0 : logT(VolConfig.shadowChunks, 1, VolConfig.MAX_CHUNKS), t -> t <= 0.001 ? "mati" : logV(t, 1, VolConfig.MAX_CHUNKS) + " chunk", t -> VolConfig.setShadowChunks(t <= 0.001 ? 0 : logV(t, 1, VolConfig.MAX_CHUNKS)))); y += rh;
    addDrawableChild(cycle(xl, y, cw, bh, "Kualitas bayangan", new String[]{"1024", "2048", "4096"}, () -> "" + VolConfig.shadowRes, v -> VolConfig.shadowRes = Integer.parseInt(v))); y += rh;
    addDrawableChild(toggle(xl, y, cw, bh, "Tekstur blok", () -> VolConfig.textures, v -> VolConfig.textures = v)); y += rh;
    addDrawableChild(toggle(xl, y, cw, bh, "Cahaya matahari", () -> VolConfig.lighting, v -> VolConfig.lighting = v)); y += rh;
    addDrawableChild(toggle(xl, y, cw, bh, "Kabut LOD", () -> VolConfig.fog, v -> VolConfig.fog = v)); y += rh;
    addDrawableChild(toggle(xl, y, cw, bh, "Log diagnostik", () -> VolConfig.debug, v -> VolConfig.debug = v));
    // --- kolom kanan: performa, generasi, kompatibilitas ---
    y = y0;
    addDrawableChild(cycle(xr, y, cw, bh, "Backend", new String[]{"auto", "indirect", "classic", "cpu"}, () -> VolConfig.backend, v -> LodManager.setBackend(v))); y += rh;
    addDrawableChild(cycle(xr, y, cw, bh, "Mode shader", new String[]{"auto", "post", "legacy"}, () -> VolConfig.shaderMode, v -> VolConfig.shaderMode = v)); y += rh;
    addDrawableChild(cycle(xr, y, cw, bh, "Mode Android/GPU lemah", new String[]{"auto", "on", "off"}, () -> VolConfig.compat, v -> { VolConfig.compat = v; LodManager.setBackend(VolConfig.backend); LodManager.applyThreads(); })); y += rh;
    addDrawableChild(new Sl(xr, y, cw, bh, "Thread worker", linT(VolConfig.buildThreads, 1, cores), t -> "" + linV(t, 1, cores), t -> { VolConfig.buildThreads = linV(t, 1, cores); LodManager.applyThreads(); })); y += rh;
    addDrawableChild(new Sl(xr, y, cw, bh, "Upload mesh/frame", linT(VolConfig.uploadsPerFrame, 1, 32), t -> "" + linV(t, 1, 32), t -> VolConfig.uploadsPerFrame = linV(t, 1, 32))); y += rh;
    addDrawableChild(new Sl(xr, y, cw, bh, "Memori cache", logT(VolConfig.memoryMb, 128, 8192), t -> logV(t, 128, 8192) + " MB", t -> VolConfig.memoryMb = logV(t, 128, 8192))); y += rh;
    addDrawableChild(new Sl(xr, y, cw, bh, "Generator chunk asli", VolConfig.genChunks <= 0 ? 0 : logT(VolConfig.genChunks, 1, 512), t -> t <= 0.001 ? "mati" : logV(t, 1, 512) + " chunk", t -> VolConfig.genChunks = t <= 0.001 ? 0 : logV(t, 1, 512))); y += rh;
    addDrawableChild(toggle(xr, y, cw, bh, "Sintesis terrain jauh", () -> VolConfig.synth, v -> VolConfig.synth = v)); y += rh;
    addDrawableChild(toggle(xr, y, cw, bh, "Ingest chunk dimuat", () -> VolConfig.ingest, v -> VolConfig.ingest = v));
    // --- bawah ---
    int yb = y0 + rows * rh + 6;
    addDrawableChild(ButtonWidget.builder(Text.literal("Reset default"), b -> { VolConfig.resetDefaults(); LodManager.setBackend("auto"); LodManager.applyThreads(); clearAndInit(); }).dimensions(xl, yb, cw, bh).build());
    addDrawableChild(ButtonWidget.builder(Text.literal("Selesai"), b -> close()).dimensions(xr, yb, cw, bh).build());
  }
  @Override public void close() { VolConfig.save(); if (client != null) client.setScreen(parent); }
}
