package com.voltrace.client.core.rendering;
import com.voltrace.common.world.LodOctree;
import org.joml.Matrix4f;
/** Parameter satu frame. Semua posisi dunia dipakai relatif kamera agar presisi float aman sampai 130k blok. */
public record Frame(float[] mvp, double cx, double cy, double cz, float fogStart, float fogEnd, float[] fog, float light,
                    LodOctree tree, Matrix4f view, float tanX, float tanY, double vanillaB, double maxB,
                    float[] sun, float[] lightMvp, float[] shadowP, float[] opt, boolean shadowPass, int shadowTex) {
  /** Salinan untuk pass bayangan: memakai matriks cahaya dan program depth-only. */
  public Frame asShadow(float[] lm) { return new Frame(lm, cx, cy, cz, fogStart, fogEnd, fog, light, tree, view, tanX, tanY, vanillaB, maxB, sun, lm, shadowP, opt, true, shadowTex); }
  public static float[] sec(LodOctree.Key k, double cx, double cy, double cz) {
    double size = 32.0 * (1L << k.level());
    return new float[]{(float) (k.sx() * size - cx), (float) (k.sy() * size - cy), (float) (k.sz() * size - cz), (float) (1L << k.level())};
  }
}
