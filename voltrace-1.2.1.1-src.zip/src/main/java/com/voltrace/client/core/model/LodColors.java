package com.voltrace.client.core.model;
import net.minecraft.block.*; import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.model.BakedQuad; import net.minecraft.client.render.model.BlockModelPart; import net.minecraft.client.render.model.BlockStateModel;
import com.voltrace.client.McReflect; import net.minecraft.registry.tag.BlockTags; import net.minecraft.registry.tag.FluidTags;
import net.minecraft.resource.Resource; import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos; import net.minecraft.util.math.Direction; import net.minecraft.util.math.random.Random;
import net.minecraft.world.EmptyBlockView; import net.minecraft.world.biome.Biome;
import javax.imageio.ImageIO; import java.awt.image.BufferedImage; import java.io.InputStream; import java.util.List; import java.util.Optional; import java.util.concurrent.ConcurrentHashMap;
/** Warna blok = rata-rata piksel tekstur PNG asli (resource pack ikut) + id tile tekstur atas/sisi di TileAtlas. Blok ber-tint dikalikan warna biome. */
public final class LodColors {
  /** kind: 1 rumput, 2 daun, 3 air, 4 birch, 5 spruce. tiles = atas | sisi<<8 | flag<<16 (lihat Palette). */
  public record Info(int rgb, boolean tinted, int kind, int tiles) { public Info(int rgb, boolean tinted, int kind) { this(rgb, tinted, kind, 0); } }
  public static final Info NONE = new Info(0, false, -1);
  private static final ConcurrentHashMap<BlockState, Info> infos = new ConcurrentHashMap<>();

  public static void reload(MinecraftClient mc) { infos.clear(); }
  public static Info info(BlockState st) { return infos.computeIfAbsent(st, LodColors::compute); }
  private static int pack(int top, int side, int flags) { return top | side << 8 | flags << 16; }

  private static Info compute(BlockState st) {
    if (st.isAir()) return NONE;
    var fs = st.getFluidState();
    if (!fs.isEmpty()) {
      if (fs.isIn(FluidTags.WATER)) { int t = TileAtlas.register("minecraft:block/water_still"); return new Info(0xFFFFFF, true, 3, pack(t, t, 3)); }
      int t = TileAtlas.register("minecraft:block/lava_still"); return new Info(0xCF5B14, false, 0, pack(t, t, 0));
    }
    if (st.getCollisionShape(EmptyBlockView.INSTANCE, BlockPos.ORIGIN).isEmpty()) return NONE;   // rumput kecil, bunga, obor, rel
    try {
      BlockStateModel m = MinecraftClient.getInstance().getBlockRenderManager().getModel(st); Random r = Random.create(42L);
      BakedQuad quad = null, sq = null;
      for (BlockModelPart part : m.getParts(r)) { List<BakedQuad> q = part.getQuads(Direction.UP); if (!q.isEmpty()) { quad = q.get(0); break; } }
      if (quad == null) for (BlockModelPart part : m.getParts(r)) { List<BakedQuad> q = part.getQuads(null); if (!q.isEmpty()) { quad = q.get(0); break; } }
      for (BlockModelPart part : m.getParts(r)) { List<BakedQuad> q = part.getQuads(Direction.NORTH); if (!q.isEmpty()) { sq = q.get(0); break; } }
      if (quad != null) {
        String tn = McReflect.quadTexture(quad); int rgb = tn.isEmpty() ? -1 : avg(tn);
        if (rgb >= 0) {
          if (sq == null) sq = quad;
          boolean tq = quad.hasTint(), tsd = sq.hasTint();
          int tt = TileAtlas.register(tn), ts = sq == quad ? tt : TileAtlas.register(McReflect.quadTexture(sq));
          return new Info(rgb, tq, tq ? kindOf(st) : 0, pack(tt, ts, (tq ? 1 : 0) | (tsd ? 2 : 0)));
        }
      }
    } catch (Throwable ignored) {}
    MapColor mc = st.getMapColor(EmptyBlockView.INSTANCE, BlockPos.ORIGIN);
    return mc == MapColor.CLEAR ? NONE : new Info(mc.color, false, 0);
  }
  private static int kindOf(BlockState st) {
    Block b = st.getBlock(); if (b == Blocks.BIRCH_LEAVES) return 4; if (b == Blocks.SPRUCE_LEAVES) return 5; return st.isIn(BlockTags.LEAVES) ? 2 : 1;
  }
  private static int avg(String name) {
    try {
      Identifier id = Identifier.tryParse(name); if (id == null) return -1; Identifier tex = Identifier.of(id.getNamespace(), "textures/" + id.getPath() + ".png");
      Optional<Resource> res = MinecraftClient.getInstance().getResourceManager().getResource(tex); if (res.isEmpty()) return -1;
      BufferedImage img; try (InputStream in = res.get().getInputStream()) { img = ImageIO.read(in); } if (img == null) return -1;
      int w = img.getWidth(), h = Math.min(img.getHeight(), w); long r = 0, g = 0, b = 0, n = 0;   // strip animasi: ambil frame pertama
      for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) { int p = img.getRGB(x, y); if ((p >>> 24) < 128) continue; r += p >> 16 & 255; g += p >> 8 & 255; b += p & 255; n++; }
      return n == 0 ? -1 : (int) (r / n) << 16 | (int) (g / n) << 8 | (int) (b / n);
    } catch (Throwable t) { return -1; }
  }
  public static int tint(Info in, Biome bm, int x, int z) {
    return switch (in.kind()) { case 1 -> bm.getGrassColorAt(x, z); case 2 -> bm.getFoliageColor(); case 3 -> bm.getWaterColor(); case 4 -> 0x80A755; case 5 -> 0x619961; default -> 0xFFFFFF; };
  }
  public static int mul(int a, int b) { return ((a >> 16 & 255) * (b >> 16 & 255) / 255) << 16 | ((a >> 8 & 255) * (b >> 8 & 255) / 255) << 8 | (a & 255) * (b & 255) / 255; }
}
