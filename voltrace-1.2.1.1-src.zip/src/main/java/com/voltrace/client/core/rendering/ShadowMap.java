package com.voltrace.client.core.rendering;
import org.lwjgl.opengl.*;
/** Shadow map matahari untuk LOD (depth-only, ortografis, ikut kamera, snap ke grid texel agar tidak berkedip). Jalan di GL 3.2. */
public final class ShadowMap {
  private int fbo, depth, size, dummy; private final int[] vp = new int[4];
  private static int makeDepth(int s) {
    int prev = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D), t = GL11.glGenTextures(); GL11.glBindTexture(GL11.GL_TEXTURE_2D, t);
    GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL14.GL_DEPTH_COMPONENT24, s, s, 0, GL11.GL_DEPTH_COMPONENT, GL11.GL_FLOAT, 0L);
    GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR); GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
    GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL12.GL_CLAMP_TO_EDGE); GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL12.GL_CLAMP_TO_EDGE);
    GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL14.GL_TEXTURE_COMPARE_MODE, GL30.GL_COMPARE_REF_TO_TEXTURE); GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL14.GL_TEXTURE_COMPARE_FUNC, GL11.GL_LEQUAL);
    GL11.glBindTexture(GL11.GL_TEXTURE_2D, prev); return t;
  }
  /** Tekstur yang aman dipasang ke sampler bayangan saat bayangan mati. */
  public int dummyTex() { if (dummy == 0) dummy = makeDepth(4); return dummy; }
  public int depthTex() { return depth; }
  public void ensure(int s) {
    if (fbo != 0 && s == size) return;
    int prevF = GL11.glGetInteger(GL30.GL_FRAMEBUFFER_BINDING);
    if (fbo != 0) { GL30.glDeleteFramebuffers(fbo); GL11.glDeleteTextures(depth); fbo = 0; }
    depth = makeDepth(s); size = s; fbo = GL30.glGenFramebuffers(); GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, fbo);
    GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_DEPTH_ATTACHMENT, GL11.GL_TEXTURE_2D, depth, 0);
    GL20.glDrawBuffers(GL11.GL_NONE); GL11.glReadBuffer(GL11.GL_NONE);
    int st = GL30.glCheckFramebufferStatus(GL30.GL_FRAMEBUFFER); GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, prevF);
    if (st != GL30.GL_FRAMEBUFFER_COMPLETE) { GL30.glDeleteFramebuffers(fbo); GL11.glDeleteTextures(depth); fbo = 0; size = 0; throw new IllegalStateException("FBO bayangan tidak lengkap: " + st); }
  }
  public void begin() {
    GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, fbo); GL11.glGetIntegerv(GL11.GL_VIEWPORT, vp); GL11.glViewport(0, 0, size, size);
    GL11.glColorMask(false, false, false, false); GL11.glDepthMask(true); GL11.glEnable(GL11.GL_DEPTH_TEST); GL11.glDepthFunc(GL11.GL_LEQUAL);
    GL11.glClear(GL11.GL_DEPTH_BUFFER_BIT); GL11.glEnable(GL11.GL_POLYGON_OFFSET_FILL); GL11.glPolygonOffset(2.0f, 4.0f);
  }
  public void end(int prevFbo) {
    GL11.glDisable(GL11.GL_POLYGON_OFFSET_FILL); GL11.glColorMask(true, true, true, true);
    GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, prevFbo); GL11.glViewport(vp[0], vp[1], vp[2], vp[3]);
  }
}
