package me.zekyoos.voltracemods.common;

/** Dependency-free self test. Run: java -cp out me.zekyoos.voltracemods.common.CoreSelfTest */
public final class CoreSelfTest {
    static void check(boolean ok, String msg) { if (!ok) throw new AssertionError(msg); System.out.println("PASS " + msg); }

    public static void main(String[] a) throws Exception {
        // 1. cliff produces a skirt
        TileStore s = new TileStore();
        LodTile hi = flat(80, 0x55AA55), lo = flat(60, 0x888888);
        s.put(0, 0, hi); s.put(1, 0, lo);
        MeshData m = LodMesher.build(s, 0, 0, 16);
        check(m.quads == 2 /*2 tops*/ + 1 /*skirt east of tile0*/, "cliff => 2 tops + 1 skirt, got " + m.quads);

        // 2. no data => empty
        check(LodMesher.build(new TileStore(), 5, 5, 8).quads == 0, "empty region => 0 quads");

        // 3. full pipeline with async meshing
        LodConfig cfg = LodConfig.autoDetect();
        cfg.distanceBlocks = 640; cfg.maxQuadsPerFrame = 1_000_000;
        try (LodManager mgr = new LodManager(cfg)) {
            for (int tz = -40; tz <= 40; tz++) for (int tx = -40; tx <= 40; tx++) mgr.store.put(tx, tz, terrain(tx, tz));
            long t0 = System.nanoTime();
            for (int i = 0; i < 400 && (i < 2 || mgr.pendingJobs() > 0 || i < 60); i++) { mgr.update(0, 0, 160); Thread.sleep(5); }
            while (mgr.pendingJobs() > 0) Thread.sleep(5);
            for (int i = 0; i < 20; i++) { mgr.update(0, 0, 160); Thread.sleep(20); }
            while (mgr.pendingJobs() > 0) Thread.sleep(5);
            var vis = mgr.visible(0, 0, 160);
            int q = vis.stream().mapToInt(x -> x.quads).sum();
            System.out.printf("meshed %d regions, %d quads in %d ms (preset %s, %d threads)%n",
                    vis.size(), q, (System.nanoTime() - t0) / 1_000_000, cfg.quality, cfg.workerThreads);
            check(q > 1000, "pipeline produced quads");
            // vanilla exclusion: regions fully inside radius are skipped
            var near = mgr.visible(0, 0, 100_000);
            check(near.isEmpty(), "regions inside vanilla radius are not drawn");
            // budget
            cfg.maxQuadsPerFrame = 5000;
            check(mgr.visible(0, 0, 160).stream().mapToInt(x -> x.quads).sum() <= 5000, "quad budget respected");
        }
        // 3b. live thread resize + config round trip
        try (LodManager m2 = new LodManager(LodConfig.autoDetect())) {
            m2.setWorkerThreads(6); check(m2.workerThreads() == 6, "pool grows to 6");
            m2.setWorkerThreads(2); check(m2.workerThreads() == 2, "pool shrinks to 2");
        }
        java.nio.file.Path tmp = java.nio.file.Files.createTempFile("vt", ".properties");
        java.nio.file.Files.delete(tmp);
        LodConfig lc = LodConfig.loadOrCreate(tmp);
        lc.renderLod = false; lc.ingest = false; lc.distanceBlocks = 900; lc.save();
        LodConfig lc2 = LodConfig.loadOrCreate(tmp);
        check(!lc2.renderLod && !lc2.ingest && lc2.distanceBlocks == 900, "config persists renderLod/ingest/distance");
        // 4. eviction
        TileStore e = new TileStore();
        for (int i = 0; i < 100; i++) e.put(i, 0, flat(1, 0));
        e.trim(50, 0, 0);
        check(e.size() == 50 && e.get(0, 0) != null && e.get(99, 0) == null, "trim evicts farthest tiles");
        System.out.println("ALL OK");
    }

    static LodTile flat(int h, int rgb) { LodTile t = new LodTile(); java.util.Arrays.fill(t.height, (short) h); java.util.Arrays.fill(t.rgb, rgb); return t; }
    static LodTile terrain(int tx, int tz) {
        LodTile t = new LodTile();
        for (int z = 0; z < 16; z++) for (int x = 0; x < 16; x++) {
            double wx = tx * 16 + x, wz = tz * 16 + z;
            t.height[LodTile.idx(x, z)] = (short) (64 + 20 * Math.sin(wx / 37.0) * Math.cos(wz / 29.0));
            t.rgb[LodTile.idx(x, z)] = 0x4C9A3A;
        }
        return t;
    }
}
