package me.zekyoos.voltracemods.common;

/** One 16x16 chunk column grid: top surface height and RGB colour per block column. */
public final class LodTile {
    public static final int SIZE = 16;
    public final short[] height = new short[SIZE * SIZE];
    public final int[] rgb = new int[SIZE * SIZE];

    public static int idx(int lx, int lz) { return (lz << 4) | lx; }
}
