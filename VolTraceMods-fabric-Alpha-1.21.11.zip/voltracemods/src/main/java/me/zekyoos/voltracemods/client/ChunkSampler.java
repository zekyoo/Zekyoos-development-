package me.zekyoos.voltracemods.client;

import me.zekyoos.voltracemods.common.LodTile;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.material.MapColor;

/** Reads a loaded chunk into a LodTile (surface height + map colour). Cheap: 256 columns. */
final class ChunkSampler {
    private static final int WATER = 0x3F76E4, FALLBACK = 0x808080;

    static LodTile sample(Level level, LevelChunk chunk) {
        LodTile t = new LodTile();
        int minX = chunk.getPos().getMinBlockX(), minZ = chunk.getPos().getMinBlockZ();
        int minY = level.getMinY();
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int z = 0; z < 16; z++) {
            for (int x = 0; x < 16; x++) {
                int y = Math.max(minY, chunk.getHeight(Heightmap.Types.WORLD_SURFACE, x, z) - 1);
                p.set(minX + x, y, minZ + z);
                BlockState s = chunk.getBlockState(p);
                int rgb;
                if (!s.getFluidState().isEmpty()) {
                    rgb = WATER;
                } else if (s.isAir()) {
                    rgb = 0x202020;
                } else {
                    MapColor mc = s.getMapColor(chunk, p);
                    rgb = (mc == null || mc.col == 0) ? FALLBACK : mc.col;
                }
                int i = LodTile.idx(x, z);
                t.height[i] = (short) y;
                t.rgb[i] = rgb;
            }
        }
        return t;
    }

    private ChunkSampler() { }
}
