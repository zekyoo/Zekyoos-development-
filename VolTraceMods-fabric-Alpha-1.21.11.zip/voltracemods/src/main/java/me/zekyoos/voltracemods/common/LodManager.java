package me.zekyoos.voltracemods.common;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/** Decides which regions need (re)meshing, runs meshing on a small low-priority pool, serves visible meshes. */
public final class LodManager implements AutoCloseable {
    private static final class Region {
        volatile MeshData mesh = MeshData.EMPTY;
        volatile int step = -1;
        volatile boolean stale = true;
        final AtomicBoolean building = new AtomicBoolean();
    }

    public final TileStore store = new TileStore();
    private final LodConfig cfg;
    private final ConcurrentHashMap<Long, Region> regions = new ConcurrentHashMap<>();
    private final ThreadPoolExecutor pool;
    private final AtomicInteger pending = new AtomicInteger();

    public LodManager(LodConfig cfg) {
        this.cfg = cfg;
        int n = Math.max(1, cfg.workerThreads);
        this.pool = new ThreadPoolExecutor(n, n, 30, TimeUnit.SECONDS, new LinkedBlockingQueue<>(), r -> {
            Thread t = new Thread(r, "VolTraceMods-mesher");
            t.setDaemon(true);
            t.setPriority(Thread.MIN_PRIORITY);
            return t;
        });
        this.pool.allowCoreThreadTimeOut(true);
    }

    /** Resize the meshing pool live (Sodium menu "Service threads"). */
    public void setWorkerThreads(int n) {
        n = Math.max(1, Math.min(16, n));
        if (n > pool.getMaximumPoolSize()) { pool.setMaximumPoolSize(n); pool.setCorePoolSize(n); }
        else { pool.setCorePoolSize(n); pool.setMaximumPoolSize(n); }
    }

    public int workerThreads() { return pool.getMaximumPoolSize(); }

    public int pendingJobs() { return pending.get(); }

    /** Call every ~10 ticks from the client thread. */
    public void update(double camX, double camZ, int vanillaRadiusBlocks) {
        for (long k : store.drainDirty()) regions.computeIfAbsent(k, x -> new Region()).stale = true;
        store.trim(cfg.maxTiles, (int) Math.floor(camX / 16), (int) Math.floor(camZ / 16));

        int reach = cfg.distanceBlocks / LodMesher.REGION_BLOCKS + 1;
        int crx = Math.floorDiv((int) Math.floor(camX), LodMesher.REGION_BLOCKS);
        int crz = Math.floorDiv((int) Math.floor(camZ), LodMesher.REGION_BLOCKS);

        record Cand(long key, double dist, int step) { }
        List<Cand> cands = new ArrayList<>();
        for (int dz = -reach; dz <= reach; dz++) {
            for (int dx = -reach; dx <= reach; dx++) {
                int rx = crx + dx, rz = crz + dz;
                double d = regionDist(rx, rz, camX, camZ);
                if (d > cfg.distanceBlocks + LodMesher.REGION_BLOCKS || d + 46 < vanillaRadiusBlocks) continue;
                long key = TileStore.key(rx, rz);
                Region r = regions.get(key);
                int want = cfg.stepForDistance(d);
                if (r == null) { r = new Region(); regions.put(key, r); }
                if ((r.stale || r.step != want) && !r.building.get()) cands.add(new Cand(key, d, want));
            }
        }
        cands.sort((a, b) -> Double.compare(a.dist, b.dist));
        for (int i = 0; i < cands.size() && i < cfg.maxJobsPerUpdate; i++) submit(cands.get(i).key, cands.get(i).step);

        regions.entrySet().removeIf(e -> regionDist(TileStore.keyX(e.getKey()), TileStore.keyZ(e.getKey()), camX, camZ)
                > cfg.distanceBlocks + 3 * LodMesher.REGION_BLOCKS && !e.getValue().building.get());
    }

    private void submit(long key, int step) {
        Region r = regions.get(key);
        if (r == null || !r.building.compareAndSet(false, true)) return;
        r.stale = false; // re-marked by store if tiles change while we build
        pending.incrementAndGet();
        pool.execute(() -> {
            try {
                r.mesh = LodMesher.build(store, TileStore.keyX(key), TileStore.keyZ(key), step);
                r.step = step;
            } catch (Throwable t) {
                r.stale = true;
            } finally {
                r.building.set(false);
                pending.decrementAndGet();
            }
        });
    }

    /** Meshes to draw this frame, nearest first, capped by the per-frame quad budget. */
    public List<MeshData> visible(double camX, double camZ, int vanillaRadiusBlocks) {
        record Item(double d, MeshData m) { }
        List<Item> items = new ArrayList<>();
        for (var e : regions.entrySet()) {
            MeshData m = e.getValue().mesh;
            if (m.quads == 0) continue;
            double d = regionDist(TileStore.keyX(e.getKey()), TileStore.keyZ(e.getKey()), camX, camZ);
            if (d + 46 < vanillaRadiusBlocks || d > cfg.distanceBlocks + LodMesher.REGION_BLOCKS) continue;
            items.add(new Item(d, m));
        }
        items.sort((a, b) -> Double.compare(a.d, b.d));
        List<MeshData> out = new ArrayList<>();
        int budget = cfg.maxQuadsPerFrame;
        for (Item it : items) {
            if (budget - it.m.quads < 0) break;
            budget -= it.m.quads;
            out.add(it.m);
        }
        return out;
    }

    private static double regionDist(int rx, int rz, double camX, double camZ) {
        double cx = (rx + 0.5) * LodMesher.REGION_BLOCKS, cz = (rz + 0.5) * LodMesher.REGION_BLOCKS;
        return Math.hypot(cx - camX, cz - camZ);
    }

    @Override public void close() { pool.shutdownNow(); }
}
