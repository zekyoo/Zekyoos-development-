package me.zekyoos.voltracemods.client.config;

import me.zekyoos.voltracemods.client.VolTraceClient;
import me.zekyoos.voltracemods.common.LodConfig;
import net.caffeinemc.mods.sodium.api.config.ConfigEntryPoint;
import net.caffeinemc.mods.sodium.api.config.structure.ConfigBuilder;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

/**
 * Adds a "VolTraceMods" page to Sodium's Video Settings screen (Sodium 0.8+ Config API, MC 1.21.11),
 * the same place Voxy puts its page. Registered via the "sodium:config_api_user" entrypoint in
 * fabric.mod.json; the class is only ever loaded by Sodium, so the mod works without Sodium too.
 */
public final class VolTraceConfigMenu implements ConfigEntryPoint {
    private static Identifier id(String path) { return Identifier.fromNamespaceAndPath(VolTraceClient.MOD_ID, path); }
    private static Component t(String key) { return Component.translatable("voltracemods.config." + key); }

    @Override
    public void registerConfigLate(ConfigBuilder builder) {
        final LodConfig c = VolTraceClient.config();
        final Runnable flush = c::save; // Sodium calls this once after Apply

        builder.registerOwnModOptions()
                .setIcon(Identifier.fromNamespaceAndPath(VolTraceClient.MOD_ID, "textures/gui/icon.png"))
                .addPage(builder.createOptionPage()
                        .setName(t("title"))
                        // ---------------- General ----------------
                        .addOptionGroup(builder.createOptionGroup()
                                .setName(t("general"))
                                .addOption(builder.createBooleanOption(id("enabled"))
                                        .setName(t("general.enabled"))
                                        .setTooltip(t("general.enabled.tooltip"))
                                        .setStorageHandler(flush)
                                        .setBinding(v -> c.enabled = v, () -> c.enabled)
                                        .setDefaultValue(true))
                                .addOption(builder.createIntegerOption(id("service_threads"))
                                        .setName(t("general.serviceThreads"))
                                        .setTooltip(t("general.serviceThreads.tooltip"))
                                        .setStorageHandler(flush)
                                        .setRange(1, Math.max(2, Math.min(8, Runtime.getRuntime().availableProcessors())), 1)
                                        .setValueFormatter(v -> Component.literal(Integer.toString(v)))
                                        .setBinding(v -> {
                                            c.workerThreads = v;
                                            if (VolTraceClient.manager() != null) VolTraceClient.manager().setWorkerThreads(v);
                                        }, () -> c.workerThreads)
                                        .setDefaultValue(2))
                                .addOption(builder.createBooleanOption(id("ingest"))
                                        .setName(t("general.ingest"))
                                        .setTooltip(t("general.ingest.tooltip"))
                                        .setStorageHandler(flush)
                                        .setBinding(v -> c.ingest = v, () -> c.ingest)
                                        .setDefaultValue(true)))
                        // ---------------- Rendering ----------------
                        .addOptionGroup(builder.createOptionGroup()
                                .setName(t("rendering"))
                                .addOption(builder.createBooleanOption(id("render_lod"))
                                        .setName(t("general.rendering"))
                                        .setTooltip(t("general.rendering.tooltip"))
                                        .setStorageHandler(flush)
                                        .setBinding(v -> c.renderLod = v, () -> c.renderLod)
                                        .setDefaultValue(true))
                                .addOption(builder.createIntegerOption(id("render_distance"))
                                        .setName(t("general.renderDistance"))
                                        .setTooltip(t("general.renderDistance.tooltip"))
                                        .setStorageHandler(flush)
                                        .setRange(8, 256, 8)
                                        .setValueFormatter(v -> Component.literal(v + " chunks"))
                                        .setBinding(v -> c.distanceBlocks = v * 16, () -> c.distanceBlocks / 16)
                                        .setDefaultValue(40))
                                .addOption(builder.createIntegerOption(id("quality"))
                                        .setName(t("general.quality"))
                                        .setTooltip(t("general.quality.tooltip"))
                                        .setStorageHandler(flush)
                                        .setRange(0, 2, 1)
                                        .setValueFormatter(v -> Component.literal(
                                                LodConfig.Quality.values()[Math.max(0, Math.min(2, v))].name()))
                                        .setBinding(v -> c.quality = LodConfig.Quality.values()[Math.max(0, Math.min(2, v))],
                                                () -> c.quality.ordinal())
                                        .setDefaultValue(1))
                                .addOption(builder.createIntegerOption(id("max_quads"))
                                        .setName(t("general.maxQuads"))
                                        .setTooltip(t("general.maxQuads.tooltip"))
                                        .setStorageHandler(flush)
                                        .setRange(10, 300, 10)
                                        .setValueFormatter(v -> Component.literal(v + "k quads"))
                                        .setBinding(v -> c.maxQuadsPerFrame = v * 1000, () -> c.maxQuadsPerFrame / 1000)
                                        .setDefaultValue(80))
                                .addOption(builder.createBooleanOption(id("disable_with_shaders"))
                                        .setName(t("general.disableWithShaders"))
                                        .setTooltip(t("general.disableWithShaders.tooltip"))
                                        .setStorageHandler(flush)
                                        .setBinding(v -> c.disableWithShaders = v, () -> c.disableWithShaders)
                                        .setDefaultValue(false))));
    }
}
