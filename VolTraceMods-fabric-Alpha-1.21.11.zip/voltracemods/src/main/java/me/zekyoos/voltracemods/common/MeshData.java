package me.zekyoos.voltracemods.common;

/** Quads: 12 floats (4 xyz vertices, world-space) + 1 ARGB colour each. */
public final class MeshData {
    public static final MeshData EMPTY = new MeshData(new float[0], new int[0], 0);
    public final float[] pos;
    public final int[] argb;
    public final int quads;

    MeshData(float[] pos, int[] argb, int quads) { this.pos = pos; this.argb = argb; this.quads = quads; }
}
