package me.zekyoos.voltracemods.common;

import java.util.Arrays;

/** Builds a region mesh on the CPU: one top quad per cell plus skirts down to lower neighbours. */
public final class LodMesher {
    public static final int REGION_TILES = 4;
    public static final int REGION_BLOCKS = REGION_TILES * LodTile.SIZE;

    private LodMesher() { }

    private static final class Cell { int h; int rgb; }

    public static MeshData build(TileStore store, int rx, int rz, int step) {
        Builder b = new Builder();
        int x0 = rx * REGION_BLOCKS, z0 = rz * REGION_BLOCKS;
        Cell c = new Cell(), n = new Cell();
        for (int cz = 0; cz < REGION_BLOCKS; cz += step) {
            for (int cx = 0; cx < REGION_BLOCKS; cx += step) {
                int bx = x0 + cx, bz = z0 + cz;
                if (!sample(store, bx, bz, step, c)) continue;
                float top = c.h + 1f;
                b.quad(bx, top, bz, bx + step, top, bz, bx + step, top, bz + step, bx, top, bz + step, shade(c.rgb, 1.0f));
                if (sample(store, bx - step, bz, step, n) && n.h < c.h)
                    b.quad(bx, top, bz + step, bx, top, bz, bx, n.h + 1f, bz, bx, n.h + 1f, bz + step, shade(c.rgb, 0.8f));
                if (sample(store, bx + step, bz, step, n) && n.h < c.h)
                    b.quad(bx + step, top, bz, bx + step, top, bz + step, bx + step, n.h + 1f, bz + step, bx + step, n.h + 1f, bz, shade(c.rgb, 0.8f));
                if (sample(store, bx, bz - step, step, n) && n.h < c.h)
                    b.quad(bx, top, bz, bx + step, top, bz, bx + step, n.h + 1f, bz, bx, n.h + 1f, bz, shade(c.rgb, 0.6f));
                if (sample(store, bx, bz + step, step, n) && n.h < c.h)
                    b.quad(bx + step, top, bz + step, bx, top, bz + step, bx, n.h + 1f, bz + step, bx + step, n.h + 1f, bz + step, shade(c.rgb, 0.6f));
            }
        }
        return b.finish();
    }

    /** Max height + average colour of the step x step columns starting at (bx,bz). False if no data. */
    private static boolean sample(TileStore store, int bx, int bz, int step, Cell out) {
        int maxH = Integer.MIN_VALUE, r = 0, g = 0, bl = 0, count = 0;
        long lastKey = Long.MIN_VALUE; LodTile tile = null;
        for (int z = bz; z < bz + step; z++) {
            for (int x = bx; x < bx + step; x++) {
                int tx = Math.floorDiv(x, LodTile.SIZE), tz = Math.floorDiv(z, LodTile.SIZE);
                long k = TileStore.key(tx, tz);
                if (k != lastKey) { tile = store.get(tx, tz); lastKey = k; }
                if (tile == null) continue;
                int i = LodTile.idx(Math.floorMod(x, LodTile.SIZE), Math.floorMod(z, LodTile.SIZE));
                if (tile.height[i] > maxH) maxH = tile.height[i];
                int col = tile.rgb[i];
                r += (col >> 16) & 255; g += (col >> 8) & 255; bl += col & 255; count++;
            }
        }
        if (count == 0) return false;
        out.h = maxH;
        out.rgb = ((r / count) << 16) | ((g / count) << 8) | (bl / count);
        return true;
    }

    private static int shade(int rgb, float f) {
        int r = (int) (((rgb >> 16) & 255) * f), g = (int) (((rgb >> 8) & 255) * f), b = (int) ((rgb & 255) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private static final class Builder {
        float[] pos = new float[12 * 256];
        int[] col = new int[256];
        int quads;

        void quad(float x0, float y0, float z0, float x1, float y1, float z1,
                  float x2, float y2, float z2, float x3, float y3, float z3, int argb) {
            if (quads == col.length) { pos = Arrays.copyOf(pos, pos.length * 2); col = Arrays.copyOf(col, col.length * 2); }
            int o = quads * 12;
            pos[o] = x0; pos[o + 1] = y0; pos[o + 2] = z0; pos[o + 3] = x1; pos[o + 4] = y1; pos[o + 5] = z1;
            pos[o + 6] = x2; pos[o + 7] = y2; pos[o + 8] = z2; pos[o + 9] = x3; pos[o + 10] = y3; pos[o + 11] = z3;
            col[quads++] = argb;
        }

        MeshData finish() {
            if (quads == 0) return MeshData.EMPTY;
            return new MeshData(Arrays.copyOf(pos, quads * 12), Arrays.copyOf(col, quads), quads);
        }
    }
}
