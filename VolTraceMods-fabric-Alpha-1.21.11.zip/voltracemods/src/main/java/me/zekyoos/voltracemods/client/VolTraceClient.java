package me.zekyoos.voltracemods.client;

import me.zekyoos.voltracemods.common.LodConfig;
import me.zekyoos.voltracemods.common.LodManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.state.CameraRenderState;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class VolTraceClient implements ClientModInitializer {
    public static final String MOD_ID = "voltracemods";
    private static final Logger LOG = LoggerFactory.getLogger("VolTraceMods");

    private static LodConfig config = LodConfig.autoDetect();
    private static LodManager manager;
    private static int tick;
    private static int renderFailures;
    private static boolean crashed;

    /** Config shared with the Sodium menu. Never null. */
    public static LodConfig config() { return config; }
    public static LodManager manager() { return manager; }

    @Override
    public void onInitializeClient() {
        config = LodConfig.loadOrCreate(FabricLoader.getInstance().getConfigDir().resolve(MOD_ID + ".properties"));
        manager = new LodManager(config);
        LOG.info("VolTraceMods by Zekyoos active. Detected mods: {} | shader mod present: {}",
                Compat.describe(), Compat.shaderModPresent());

        // Chunks are remembered after vanilla unloads them -> LOD covers everything you have explored.
        ClientChunkEvents.CHUNK_LOAD.register((level, chunk) -> {
            if (!active() || !config.ingest) return;
            var pos = chunk.getPos();
            manager.store.put(Math.floorDiv(pos.getMinBlockX(), 16), Math.floorDiv(pos.getMinBlockZ(), 16),
                    ChunkSampler.sample(level, chunk));
        });

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (!active() || mc.player == null || mc.level == null || ++tick % 10 != 0) return;
            manager.update(mc.player.getX(), mc.player.getZ(), vanillaRadiusBlocks(mc));
        });

        // Fabric API 0.141 / MC 1.21.11: net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents
        WorldRenderEvents.AFTER_ENTITIES.register(ctx -> {
            if (!active() || !config.renderLod || ctx.consumers() == null) return;
            if (config.disableWithShaders && Compat.shaderPackActive()) return;
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null) return;

            // Real camera position: correct for first person, third person (back / front) and free-cam mods.
            Vec3 cam;
            CameraRenderState cs = ctx.worldState().cameraRenderState;
            cam = (cs != null && cs.initialized) ? cs.pos : mc.player.getEyePosition();

            try {
                LodRenderer.draw(ctx.matrices(), ctx.consumers(),
                        manager.visible(cam.x, cam.z, vanillaRadiusBlocks(mc)), cam.x, cam.y, cam.z);
            } catch (Throwable t) {
                // Another mod / shader pack interfered: never crash the game; disable after repeated failures.
                if (++renderFailures >= 3) {
                    LOG.error("LOD rendering failed {} times (mod/shader conflict?). Disabling VolTraceMods.", renderFailures, t);
                    crashed = true;
                }
            }
        });
    }

    private static boolean active() { return config.enabled && !crashed && manager != null; }

    private static int vanillaRadiusBlocks(Minecraft mc) {
        return mc.options.getEffectiveRenderDistance() * 16;
    }
}
