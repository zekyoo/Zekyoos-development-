package me.zekyoos.voltracemods.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import me.zekyoos.voltracemods.common.MeshData;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.rendertype.RenderTypes;

import java.util.List;

/**
 * Draws CPU-built meshes through vanilla's own position+colour pipeline (RenderTypes.debugQuads).
 * No custom shaders, no GL 4.x. Vertices are emitted relative to the REAL camera position, so the
 * result is identical in first person, third person (back/front) and with free-cam style mods.
 */
final class LodRenderer {
    /** Sink LOD slightly so vanilla chunks always win the depth test where they overlap. */
    private static final float SINK = 1.5f;

    static void draw(PoseStack stack, MultiBufferSource buffers, List<MeshData> meshes,
                     double camX, double camY, double camZ) {
        VertexConsumer vc = buffers.getBuffer(RenderTypes.debugQuads());
        PoseStack.Pose pose = stack.last();
        for (MeshData m : meshes) {
            for (int q = 0; q < m.quads; q++) {
                int o = q * 12, c = m.argb[q];
                for (int v = 0; v < 4; v++) {
                    vc.addVertex(pose,
                            (float) (m.pos[o + v * 3] - camX),
                            (float) (m.pos[o + v * 3 + 1] - camY) - SINK,
                            (float) (m.pos[o + v * 3 + 2] - camZ)).setColor(c);
                }
            }
        }
    }

    private LodRenderer() { }
}
