package me.zekyoos.voltracemods.common;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/** Thread-safe store of sampled chunk tiles plus dirty-region tracking. */
public final class TileStore {
    private final ConcurrentHashMap<Long, LodTile> tiles = new ConcurrentHashMap<>();
    private final Set<Long> dirtyRegions = ConcurrentHashMap.newKeySet();

    public static long key(int x, int z) { return ((long) x << 32) | (z & 0xFFFFFFFFL); }
    public static int keyX(long k) { return (int) (k >> 32); }
    public static int keyZ(long k) { return (int) k; }

    public void put(int tx, int tz, LodTile t) {
        tiles.put(key(tx, tz), t);
        int rx = Math.floorDiv(tx, LodMesher.REGION_TILES), rz = Math.floorDiv(tz, LodMesher.REGION_TILES);
        int lx = Math.floorMod(tx, LodMesher.REGION_TILES), lz = Math.floorMod(tz, LodMesher.REGION_TILES);
        int dx0 = lx == 0 ? -1 : 0, dx1 = lx == LodMesher.REGION_TILES - 1 ? 1 : 0;
        int dz0 = lz == 0 ? -1 : 0, dz1 = lz == LodMesher.REGION_TILES - 1 ? 1 : 0;
        for (int dz = dz0; dz <= dz1; dz++) for (int dx = dx0; dx <= dx1; dx++) dirtyRegions.add(key(rx + dx, rz + dz));
    }

    public LodTile get(int tx, int tz) { return tiles.get(key(tx, tz)); }
    public int size() { return tiles.size(); }

    public List<Long> drainDirty() {
        List<Long> out = new ArrayList<>();
        for (Long k : dirtyRegions) if (dirtyRegions.remove(k)) out.add(k);
        return out;
    }

    /** Evict the tiles farthest from the centre when over capacity. */
    public void trim(int maxTiles, int centerTx, int centerTz) {
        int over = tiles.size() - maxTiles;
        if (over <= 0) return;
        List<Map.Entry<Long, LodTile>> all = new ArrayList<>(tiles.entrySet());
        all.sort((a, b) -> Long.compare(dist2(b.getKey(), centerTx, centerTz), dist2(a.getKey(), centerTx, centerTz)));
        for (int i = 0; i < over && i < all.size(); i++) tiles.remove(all.get(i).getKey());
    }

    private static long dist2(long k, int cx, int cz) {
        long dx = keyX(k) - cx, dz = keyZ(k) - cz;
        return dx * dx + dz * dz;
    }
}
