package me.zekyoos.voltracemods.common;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Settings. Auto-detects a sane preset for weak CPUs / ARM (phones, Pojav) / low RAM. */
public final class LodConfig {
    public enum Quality { LOW, MEDIUM, HIGH }

    public boolean enabled = true;
    /** Draw LODs (can be toggled live from the Sodium menu). */
    public boolean renderLod = true;
    /** Convert newly loaded chunks into LOD data. */
    public boolean ingest = true;
    /** If a shader pack (Iris/OptiFine) is active and LOD looks wrong, set true to hide LOD while shaders run. */
    public boolean disableWithShaders = false;
    public int distanceBlocks = 640;
    public Quality quality = Quality.MEDIUM;
    public int maxQuadsPerFrame = 80_000;
    public int workerThreads = 2;
    public int maxJobsPerUpdate = 6;
    public int maxTiles = 20_000;

    /** Cell size in blocks for near / mid / far rings. Must be powers of two, 4..32. */
    public int[] steps() {
        return switch (quality) {
            case LOW -> new int[]{16, 32, 32};
            case MEDIUM -> new int[]{8, 16, 32};
            case HIGH -> new int[]{4, 8, 16};
        };
    }

    public int stepForDistance(double d) {
        int[] s = steps();
        double f = d / Math.max(1, distanceBlocks);
        return f < 0.35 ? s[0] : f < 0.7 ? s[1] : s[2];
    }

    public static LodConfig autoDetect() {
        LodConfig c = new LodConfig();
        int cores = Runtime.getRuntime().availableProcessors();
        long maxMemMb = Runtime.getRuntime().maxMemory() / (1024 * 1024);
        String arch = System.getProperty("os.arch", "").toLowerCase();
        boolean arm = arch.contains("aarch64") || arch.contains("arm");
        if (arm || cores <= 4 || maxMemMb < 1536) {
            c.quality = Quality.LOW; c.distanceBlocks = 384; c.workerThreads = 1;
            c.maxQuadsPerFrame = 25_000; c.maxJobsPerUpdate = 2; c.maxTiles = 6_000;
        } else if (cores <= 8 || maxMemMb < 3072) {
            c.quality = Quality.MEDIUM; c.distanceBlocks = 640; c.workerThreads = 2;
        } else {
            c.quality = Quality.HIGH; c.distanceBlocks = 1024; c.workerThreads = Math.min(4, cores / 2);
            c.maxQuadsPerFrame = 160_000; c.maxTiles = 40_000;
        }
        return c;
    }

    private Path file;

    /** Persist to the file this config was loaded from (called by the Sodium menu after Apply). */
    public void save() { if (file != null) save(file); }

    public static LodConfig loadOrCreate(Path file) {
        LodConfig c = autoDetect();
        c.file = file;
        if (Files.exists(file)) {
            try (Reader r = Files.newBufferedReader(file)) {
                Properties p = new Properties(); p.load(r);
                c.enabled = Boolean.parseBoolean(p.getProperty("enabled", "" + c.enabled));
                c.renderLod = Boolean.parseBoolean(p.getProperty("renderLod", "" + c.renderLod));
                c.ingest = Boolean.parseBoolean(p.getProperty("ingest", "" + c.ingest));
                c.disableWithShaders = Boolean.parseBoolean(p.getProperty("disableWithShaders", "" + c.disableWithShaders));
                c.distanceBlocks = clamp(p, "distanceBlocks", c.distanceBlocks, 128, 4096);
                c.quality = Quality.valueOf(p.getProperty("quality", c.quality.name()).trim().toUpperCase());
                c.maxQuadsPerFrame = clamp(p, "maxQuadsPerFrame", c.maxQuadsPerFrame, 1000, 1_000_000);
                c.workerThreads = clamp(p, "workerThreads", c.workerThreads, 1, 8);
                c.maxJobsPerUpdate = clamp(p, "maxJobsPerUpdate", c.maxJobsPerUpdate, 1, 32);
                c.maxTiles = clamp(p, "maxTiles", c.maxTiles, 500, 200_000);
            } catch (Exception ignored) { /* keep auto defaults */ }
        } else {
            c.save(file);
        }
        return c;
    }

    public void save(Path file) {
        Properties p = new Properties();
        p.setProperty("enabled", "" + enabled);
        p.setProperty("renderLod", "" + renderLod);
        p.setProperty("ingest", "" + ingest);
        p.setProperty("disableWithShaders", "" + disableWithShaders);
        p.setProperty("distanceBlocks", "" + distanceBlocks);
        p.setProperty("quality", quality.name());
        p.setProperty("maxQuadsPerFrame", "" + maxQuadsPerFrame);
        p.setProperty("workerThreads", "" + workerThreads);
        p.setProperty("maxJobsPerUpdate", "" + maxJobsPerUpdate);
        p.setProperty("maxTiles", "" + maxTiles);
        try (Writer w = Files.newBufferedWriter(file)) { p.store(w, "VolTraceMods config (quality: LOW|MEDIUM|HIGH)"); }
        catch (IOException ignored) { }
    }

    private static int clamp(Properties p, String k, int def, int lo, int hi) {
        try { return Math.max(lo, Math.min(hi, Integer.parseInt(p.getProperty(k, "" + def).trim()))); }
        catch (NumberFormatException e) { return def; }
    }
}
