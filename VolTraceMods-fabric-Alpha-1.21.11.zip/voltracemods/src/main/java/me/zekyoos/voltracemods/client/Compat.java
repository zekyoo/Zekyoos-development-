package me.zekyoos.voltracemods.client;

import net.fabricmc.loader.api.FabricLoader;

import java.lang.reflect.Method;

/**
 * Soft compatibility layer. Uses only reflection + Fabric's mod list, so VolTraceMods never hard-depends on
 * Iris / Sodium / OptiFine-compat mods and never crashes if they are absent or change their API.
 */
final class Compat {
    private static final String[] SHADER_MODS = {"iris", "oculus", "optifine", "optifabric", "optiforge"};
    private static Method irisInUse;
    private static Object irisApi;
    private static boolean irisResolved;

    static boolean shaderModPresent() {
        for (String id : SHADER_MODS) if (FabricLoader.getInstance().isModLoaded(id)) return true;
        return false;
    }

    /** True while a shader pack is actually active (Iris API via reflection). */
    static boolean shaderPackActive() {
        if (!resolveIris()) return false;
        try { return (boolean) irisInUse.invoke(irisApi); } catch (Throwable t) { return false; }
    }

    private static boolean resolveIris() {
        if (irisResolved) return irisInUse != null;
        irisResolved = true;
        if (!FabricLoader.getInstance().isModLoaded("iris")) return false;
        try {
            Class<?> api = Class.forName("net.irisshaders.iris.api.v0.IrisApi");
            irisApi = api.getMethod("getInstance").invoke(null);
            irisInUse = api.getMethod("isShaderPackInUse");
            return true;
        } catch (Throwable t) {
            irisInUse = null;
            return false;
        }
    }

    static String describe() {
        StringBuilder sb = new StringBuilder();
        for (String id : new String[]{"sodium", "iris", "oculus", "optifine", "embeddium", "indium", "nvidium", "immediatelyfast", "bobby", "distanthorizons", "voxy"})
            if (FabricLoader.getInstance().isModLoaded(id)) sb.append(id).append(' ');
        return sb.length() == 0 ? "none" : sb.toString().trim();
    }

    private Compat() { }
}
