# VolTraceMods (Fabric 1.21.11) — by Zekyoos

Far-distance LOD terrain. Meshes are built on the CPU and drawn through vanilla's own pipeline:
no compute shaders, no OpenGL 4.6. Original code (not derived from Voxy / Distant Horizons).

## Build
- Lokal: JDK 21 + `gradle build` (Gradle 9.2.1). Jar ada di `build/libs/VolTraceMods-0.1.0.jar`.
- GitHub: push repo ini, workflow `.github/workflows/build.yml` otomatis build dan upload jar sebagai artifact.

## Struktur jar (sama pola dengan Voxy)
```
fabric.mod.json
client.voltracemods.mixins.json   common.voltracemods.mixins.json   voltracemods.accesswidener
assets/voltracemods/{icon.png, lang/en_us.json, lang/id_id.json, textures/gui/icon.png}
me/zekyoos/voltracemods/{client, client/config, common}/...
META-INF/MANIFEST.MF  (ditambah Loom)
```

## Menu Sodium
Video Settings (Sodium 0.8+) -> halaman **VolTraceMods**: Enable, Service threads, Chunk Ingest, Rendering,
Render distance, LOD quality, Render budget, Hide with shader packs. Didaftarkan lewat entrypoint
`sodium:config_api_user` (Sodium Config API). Tanpa Sodium mod tetap jalan (menu saja yang tidak muncul);
setting tetap bisa diedit di `config/voltracemods.properties`.

## Kamera
LOD digambar relatif ke posisi kamera asli (`LevelRenderState.cameraRenderState.pos`), jadi sama di first person,
third person belakang/depan, dan mod free-cam.

## Kompatibilitas
Tanpa mixin (config mixin disiapkan kosong untuk integrasi shader nanti). Server apa pun. Jika render gagal 3x,
LOD mati otomatis tanpa crash. Di bawah shader pack tampilan LOD belum dijamin; pakai "Hide with shader packs".

## Status jujur
Inti `common` (Java murni) dikompilasi + dites. Lapisan `client` ditulis berdasarkan API yang dicek dari jar DH/Fabric 1.21.11
dan dokumentasi Sodium, tetapi BELUM dikompilasi. Titik paling berisiko: nama method builder Sodium (`setRange`, `setBinding`).
Hanya Fabric (DH juga NeoForge; itu pekerjaan terpisah).
