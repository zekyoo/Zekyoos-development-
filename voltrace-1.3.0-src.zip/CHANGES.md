
## 1.3.0 (berdasarkan hasil tes 1.2.2)
- LOD bergeser saat bergerak/terbang: penyebabnya FOV. Sekarang FOV dinamis asli vanilla (lari, terbang, efek, air, mod zoom) dipakai untuk proyeksi LOD (`GameRendererAccessor`).
- LOD jadi hitam pekat: kecerahan LOD terlalu rendah saat sore/malam. Ada lantai kecerahan, warna kabut diambil dari langit yang tampil di layar, shader jatuh ke warna palet bila tekstur tidak valid, layar atlas kosong = abu-abu (bukan hitam).
- Halaman VolTrace di DALAM Video Settings Sodium (5 kategori: Umum, Tampilan, Bayangan, Performa, Lanjutan) termasuk ON/OFF mod; layar cadangan tanpa Sodium dibuat ulang (sidebar kategori + tombol ON/OFF mod).
- Performa: frustum culling (sebelumnya semua section digambar tiap frame), skala render LOD 50-100%, peta bayangan diperbarui tiap N frame (bergeser mengikuti kamera di antaranya), PCF 4 tap, thread worker default lebih sedikit dan berprioritas rendah, upload mesh/frame default 4.
- Generator chunk asli dimatikan secara default (bisa membebani server dan membuat chunk vanilla hilang); tampilan jauh memakai sintesis terrain yang tidak menyentuh dunia.
- `/voltrace prepare <chunk>`: menyiapkan LOD jauh di belakang layar dan menyimpannya ke disk (seperti Chunky), `0` untuk berhenti.
- `/voltrace status` menampilkan jumlah blok bertekstur/gagal, jumlah section digambar, FOV, dan skala render. Sprite yang tidak terbaca dicatat di log.
