package com.voltrace.client.mixin.minecraft;
import com.voltrace.client.config.VolSettingsScreen;
import net.minecraft.client.MinecraftClient; import net.minecraft.client.gui.Drawable; import net.minecraft.client.gui.Element; import net.minecraft.client.gui.Selectable;
import net.minecraft.client.gui.screen.Screen; import net.minecraft.client.gui.screen.option.OptionsScreen; import net.minecraft.client.gui.screen.option.VideoOptionsScreen;
import net.minecraft.client.gui.widget.ButtonWidget; import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin; import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At; import org.spongepowered.asm.mixin.injection.Inject; import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/** Menaruh tombol "VolTrace" di Options, Video Settings vanilla, (Sodium: halaman VolTrace ada di dalam Video Settings lewat VolSodiumPage). */
@Mixin(Screen.class)
public abstract class MixinScreen {
  @Shadow protected abstract <T extends Element & Drawable & Selectable> T addDrawableChild(T child);
  @Inject(method = "init(II)V", at = @At("TAIL"), require = 0)   // di 1.21.11 signature-nya init(int, int), tanpa MinecraftClient
  private void voltrace$addButton(int w, int h, CallbackInfo ci) {
    MinecraftClient client = MinecraftClient.getInstance(); Screen self = (Screen) (Object) this;
    if (!(self instanceof OptionsScreen) && !(self instanceof VideoOptionsScreen)) return;   // Sodium punya halaman VolTrace sendiri (VolSodiumPage)
    addDrawableChild(ButtonWidget.builder(Text.literal("VolTrace"), b -> client.setScreen(new VolSettingsScreen(self))).dimensions(6, 6, 90, 20).build());
  }
}
