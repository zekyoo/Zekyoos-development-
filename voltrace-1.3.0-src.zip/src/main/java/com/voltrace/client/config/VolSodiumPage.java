package com.voltrace.client.config;
import com.voltrace.client.core.LodManager;
import net.caffeinemc.mods.sodium.api.config.ConfigEntryPoint; import net.caffeinemc.mods.sodium.api.config.StorageEventHandler;
import net.caffeinemc.mods.sodium.api.config.structure.*;
import net.minecraft.text.Text; import net.minecraft.util.Identifier;
import java.util.function.Consumer; import java.util.function.IntFunction; import java.util.function.Supplier;
/**
 * Halaman "VolTrace" di dalam Video Settings (layar Sodium), muncul di daftar mod sebelah kiri seperti Iris/Voxy.
 * Dimuat Sodium lewat entrypoint "sodium:config_api_user"; kalau Sodium tidak terpasang class ini tidak pernah dimuat
 * (di situ layar VolSettingsScreen dari Options / Mod Menu yang dipakai).
 */
public class VolSodiumPage implements ConfigEntryPoint {
  enum Backend { AUTO, INDIRECT, CLASSIC, CPU }
  enum ShaderMode { AUTO, POST, LEGACY }
  enum Compat { AUTO, ON, OFF }
  enum ShadowRes { R1024, R2048, R4096 }
  private final StorageEventHandler save = VolConfig::save;
  private static Identifier id(String s) { return Identifier.of("voltrace", s); }
  private static Text t(String s) { return Text.literal(s); }

  private BooleanOptionBuilder bool(ConfigBuilder b, String key, String name, String tip, Supplier<Boolean> get, Consumer<Boolean> set, boolean def) {
    return b.createBooleanOption(id(key)).setName(t(name)).setTooltip(t(tip)).setStorageHandler(save).setBinding(set, get).setDefaultValue(def);
  }
  private IntegerOptionBuilder num(ConfigBuilder b, String key, String name, String tip, int min, int max, int step, IntFunction<String> fmt, Supplier<Integer> get, Consumer<Integer> set, int def) {
    return b.createIntegerOption(id(key)).setName(t(name)).setTooltip(t(tip)).setStorageHandler(save).setRange(min, max, step).setValueFormatter(v -> t(fmt.apply(v))).setBinding(set, get).setDefaultValue(def);
  }
  private static <E extends Enum<E>> E parse(Class<E> c, String v, E def) { try { return Enum.valueOf(c, v.toUpperCase()); } catch (Exception e) { return def; } }

  @Override public void registerConfigLate(ConfigBuilder b) {
    OptionPageBuilder general = b.createOptionPage().setName(t("Umum"))
      .addOptionGroup(b.createOptionGroup().setName(t("VolTrace"))
        .addOption(bool(b, "enabled", "Aktifkan VolTrace", "Menyalakan / mematikan seluruh mod secara manual di dalam game.", () -> VolConfig.enabled, v -> VolConfig.enabled = v, true))
        .addOption(bool(b, "ingest", "Ingest chunk", "Chunk yang dimuat game otomatis disimpan sebagai data LOD (cara kerja sama seperti Voxy).", () -> VolConfig.ingest, v -> VolConfig.ingest = v, true))
        .addOption(bool(b, "synth", "Sintesis terrain jauh", "Membuat tampilan terrain jauh dari generator dunia tanpa membuat chunk (singleplayer). Hasilnya disimpan di disk.", () -> VolConfig.synth, v -> VolConfig.synth = v, true)))
      .addOptionGroup(b.createOptionGroup().setName(t("Eksperimental"))
        .addOption(bool(b, "generate", "Generator chunk asli", "Meminta server dunia membuat chunk asli di sekitar pemain. Lebih berat dan menulis chunk ke dunia.", () -> VolConfig.generate, v -> VolConfig.generate = v, false))
        .addOption(num(b, "gen_chunks", "Radius generator", "Sejauh mana chunk asli dibuat (dibatasi jarak render).", 1, 256, 1, v -> v + " chunk", () -> VolConfig.genChunks, v -> VolConfig.genChunks = v, 32)));

    OptionPageBuilder look = b.createOptionPage().setName(t("Tampilan"))
      .addOptionGroup(b.createOptionGroup()
        .addOption(num(b, "render_distance", "Jarak render LOD", "Jarak LOD dalam chunk. Default 64.", 2, 1024, 2, v -> v + " chunk", () -> VolConfig.renderChunks, v -> VolConfig.setChunks(v), 64))
        .addOption(bool(b, "textures", "Tekstur blok", "Memakai tekstur blok asli (resource pack ikut). OFF = warna rata-rata.", () -> VolConfig.textures, v -> VolConfig.textures = v, true))
        .addOption(bool(b, "lighting", "Cahaya matahari", "Pencahayaan terarah mengikuti posisi matahari.", () -> VolConfig.lighting, v -> VolConfig.lighting = v, true))
        .addOption(bool(b, "fog", "Kabut LOD", "Memudarkan LOD ke warna langit di tepi jarak render.", () -> VolConfig.fog, v -> VolConfig.fog = v, true)));

    OptionPageBuilder shadows = b.createOptionPage().setName(t("Bayangan"))
      .addOptionGroup(b.createOptionGroup()
        .addOption(bool(b, "shadows", "Bayangan", "Bayangan matahari pada terrain LOD (shadow map).", () -> VolConfig.shadows, v -> VolConfig.shadows = v, true))
        .addOption(num(b, "shadow_radius", "Radius bayangan", "Radius bayangan dari kamera dalam chunk. Default 64.", 4, 512, 4, v -> v + " chunk", () -> Math.max(4, VolConfig.shadowChunks), v -> VolConfig.setShadowChunks(v), 64))
        .addOption(b.createEnumOption(id("shadow_resolution"), ShadowRes.class).setName(t("Kualitas bayangan")).setTooltip(t("Resolusi shadow map. 4096 lebih tajam tapi memakai VRAM dan GPU lebih banyak.")).setStorageHandler(save)
          .setElementNameProvider(e -> t(e.name().substring(1))).setBinding(e -> VolConfig.shadowRes = Integer.parseInt(e.name().substring(1)), () -> ShadowRes.valueOf("R" + (VolConfig.shadowRes >= 4096 ? 4096 : VolConfig.shadowRes >= 2048 ? 2048 : 1024))).setDefaultValue(ShadowRes.R2048))
        .addOption(num(b, "shadow_interval", "Perbarui bayangan tiap", "Peta bayangan digambar ulang tiap N frame. Lebih besar = lebih ringan.", 1, 10, 1, v -> v + " frame", () -> VolConfig.shadowInterval, v -> VolConfig.shadowInterval = v, 3)));

    OptionPageBuilder perf = b.createOptionPage().setName(t("Performa"))
      .addOptionGroup(b.createOptionGroup()
        .addOption(num(b, "render_scale", "Skala render LOD", "Resolusi gambar LOD. 50-75% jauh lebih ringan untuk GPU lemah.", 50, 100, 25, v -> v + "%", () -> VolConfig.renderScale, v -> VolConfig.renderScale = v, 100))
        .addOption(num(b, "uploads", "Upload mesh per frame", "Lebih kecil = frame lebih stabil saat LOD baru dimuat.", 1, 32, 1, v -> "" + v, () -> VolConfig.uploadsPerFrame, v -> VolConfig.uploadsPerFrame = v, 4))
        .addOption(num(b, "threads", "Thread worker", "Thread untuk membangun mesh dan sintesis. Kurangi jika game tersendat.", 1, 8, 1, v -> "" + v, () -> Math.min(8, VolConfig.buildThreads), v -> { VolConfig.buildThreads = v; LodManager.applyThreads(); }, 2))
        .addOption(num(b, "memory", "Memori cache", "Batas RAM data LOD; sisanya dibaca dari disk.", 128, 8192, 128, v -> v + " MB", () -> VolConfig.memoryMb, v -> VolConfig.memoryMb = v, 512)));

    OptionPageBuilder advanced = b.createOptionPage().setName(t("Lanjutan"))
      .addOptionGroup(b.createOptionGroup()
        .addOption(b.createEnumOption(id("backend"), Backend.class).setName(t("Backend")).setTooltip(t("auto: GPU modern (GL4.3) / klasik (GL3.2). cpu: cadangan tanpa dukungan GPU.")).setStorageHandler(save)
          .setElementNameProvider(e -> t(e.name().toLowerCase())).setBinding(e -> { String n = e.name().toLowerCase(); if (!n.equals(VolConfig.backend)) LodManager.setBackend(n); }, () -> parse(Backend.class, VolConfig.backend, Backend.AUTO)).setDefaultValue(Backend.AUTO))
        .addOption(b.createEnumOption(id("shader_mode"), ShaderMode.class).setName(t("Mode shader pack")).setTooltip(t("Cara menggambar bersama shader pack (Iris). auto sudah tepat untuk hampir semua kasus.")).setStorageHandler(save)
          .setElementNameProvider(e -> t(e.name().toLowerCase())).setBinding(e -> VolConfig.shaderMode = e.name().toLowerCase(), () -> parse(ShaderMode.class, VolConfig.shaderMode, ShaderMode.AUTO)).setDefaultValue(ShaderMode.AUTO))
        .addOption(b.createEnumOption(id("compat"), Compat.class).setName(t("Mode Android / GPU lemah")).setTooltip(t("auto mendeteksi GPU mobile/iGPU. on = paksa mode hemat.")).setStorageHandler(save)
          .setElementNameProvider(e -> t(e.name().toLowerCase())).setBinding(e -> { String n = e.name().toLowerCase(); if (!n.equals(VolConfig.compat)) { VolConfig.compat = n; LodManager.setBackend(VolConfig.backend); LodManager.applyThreads(); } }, () -> parse(Compat.class, VolConfig.compat, Compat.AUTO)).setDefaultValue(Compat.AUTO))
        .addOption(bool(b, "debug", "Log diagnostik", "Menulis baris [diag] ke logs/latest.log untuk membantu mencari masalah.", () -> VolConfig.debug, v -> VolConfig.debug = v, false)));

    b.registerOwnModOptions().addPage(general).addPage(look).addPage(shadows).addPage(perf).addPage(advanced);
  }
}
